﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class Solution3TransformAlgorithm : ITransformAlgorithm
    {
        public string AlgorithmName { get { return "Recursion Stack<T>, longest lines, some breaks, orphaned areas"; } }

        public IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition)
        {
            // Create a structure to mark which cells have been visited:
            CellState[,] state = new CellState[map.Height, map.Width];

            // Create a running list of longest line segments:
            List<LineSegmentRef> segments = new List<LineSegmentRef>(map.Height * map.Width);

            // Create a stack to hold the locations to visit for the flood-fill algorithm:
            Stack<Point> locsToVisit = new Stack<Point>(map.Height * map.Width);
            // Start with the starting position given:
            locsToVisit.Push(startingPosition);

            // Recurse until we run out of points to visit:
            while (locsToVisit.Count > 0)
            {
                // Get the point to visit:
                Point cur = locsToVisit.Pop();

                // If this position is already visited then continue to the next point:
                if (state[cur.Y, cur.X].Visited) continue;

                // Mark this point as having been visited:
                state[cur.Y, cur.X].Visited = true;

                // Check each of four cardinal directions for solid blocks:

                // North:
                if (IsPointInRange(cur.Y - 1, 0, map.Height - 1))
                {
                    var tmp = new Point(cur.X, cur.Y - 1);
                    if (map.IsSolid(tmp))
                    {
                        if (IsPointInRange(cur.X - 1, 0, map.Width - 1) && (state[cur.Y, cur.X - 1].lsiN != null))
                        {
                            // Extending a linesegment from the left:
                            (state[cur.Y, cur.X].lsiN = state[cur.Y, cur.X - 1].lsiN).Segment.End = new Point(tmp.X + 1, cur.Y);
                        }
                        else if (IsPointInRange(cur.X + 1, 0, map.Width - 1) && (state[cur.Y, cur.X + 1].lsiN != null))
                        {
                            // Extending a linesegment from the right:
                            (state[cur.Y, cur.X].lsiN = state[cur.Y, cur.X + 1].lsiN).Segment.Begin = new Point(tmp.X, cur.Y);
                        }
                        else
                        {
                            // No linesegments to the left or right, create a new one:
                            segments.Add(
                                state[cur.Y, cur.X].lsiN = new LineSegmentRef()
                                {
                                    Segment = new LineSegment(
                                        new Point(tmp.X, cur.Y),
                                        new Point(tmp.X + 1, cur.Y)
                                    )
                                }
                            );
                        }
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }

                // East:
                if (IsPointInRange(cur.X + 1, 0, map.Width - 1))
                {
                    var tmp = new Point(cur.X + 1, cur.Y);
                    if (map.IsSolid(tmp))
                    {
                        if (IsPointInRange(cur.Y - 1, 0, map.Height - 1) && (state[cur.Y - 1, cur.X].lsiE != null))
                        {
                            // Extending a linesegment from the top:
                            (state[cur.Y, cur.X].lsiE = state[cur.Y - 1, cur.X].lsiE).Segment.End = new Point(tmp.X, tmp.Y + 1);
                        }
                        else if (IsPointInRange(cur.Y + 1, 0, map.Height - 1) && (state[cur.Y + 1, cur.X].lsiE != null))
                        {
                            // Extending a linesegment from the bottom:
                            (state[cur.Y, cur.X].lsiE = state[cur.Y + 1, cur.X].lsiE).Segment.Begin = new Point(tmp.X, tmp.Y);
                        }
                        else
                        {
                            segments.Add(
                                state[cur.Y, cur.X].lsiE = new LineSegmentRef()
                                {
                                    Segment = new LineSegment(
                                        new Point(tmp.X, tmp.Y),
                                        new Point(tmp.X, tmp.Y + 1)
                                    )
                                }
                            );
                        }
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }

                // South:
                if (IsPointInRange(cur.Y + 1, 0, map.Height - 1))
                {
                    var tmp = new Point(cur.X, cur.Y + 1);
                    if (map.IsSolid(tmp))
                    {
                        if (IsPointInRange(cur.X - 1, 0, map.Width - 1) && (state[cur.Y, cur.X - 1].lsiS != null))
                        {
                            // Extending a linesegment from the left:
                            (state[cur.Y, cur.X].lsiS = state[cur.Y, cur.X - 1].lsiS).Segment.Begin = new Point(tmp.X + 1, tmp.Y);
                        }
                        else if (IsPointInRange(cur.X + 1, 0, map.Width - 1) && (state[cur.Y, cur.X + 1].lsiS != null))
                        {
                            // Extending a linesegment from the right:
                            (state[cur.Y, cur.X].lsiS = state[cur.Y, cur.X + 1].lsiS).Segment.End = new Point(tmp.X, tmp.Y);
                        }
                        else
                        {
                            // No linesegments to the left or right, create a new one:
                            segments.Add(
                                state[cur.Y, cur.X].lsiS = new LineSegmentRef()
                                {
                                    Segment = new LineSegment(
                                        new Point(tmp.X + 1, tmp.Y),
                                        new Point(tmp.X, tmp.Y)
                                    )
                                }
                            );
                        }
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }

                // West:
                if (IsPointInRange(cur.X - 1, 0, map.Width - 1))
                {
                    var tmp = new Point(cur.X - 1, cur.Y);
                    if (map.IsSolid(tmp))
                    {
                        if (IsPointInRange(cur.Y - 1, 0, map.Height - 1) && (state[cur.Y - 1, cur.X].lsiW != null))
                        {
                            // Extending a linesegment from the top:
                            (state[cur.Y, cur.X].lsiW = state[cur.Y - 1, cur.X].lsiW).Segment.Begin = new Point(tmp.X + 1, tmp.Y + 1);
                        }
                        else if (IsPointInRange(cur.Y + 1, 0, map.Height - 1) && (state[cur.Y + 1, cur.X].lsiW != null))
                        {
                            // Extending a linesegment from the bottom:
                            (state[cur.Y, cur.X].lsiW = state[cur.Y + 1, cur.X].lsiW).Segment.End = new Point(tmp.X + 1, tmp.Y);
                        }
                        else
                        {
                            segments.Add(
                                state[cur.Y, cur.X].lsiW = new LineSegmentRef()
                                {
                                    Segment = new LineSegment(
                                        new Point(tmp.X + 1, tmp.Y + 1),
                                        new Point(tmp.X + 1, tmp.Y)
                                    )
                                }
                            );
                        }
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }
            }

            state = null;
            locsToVisit = null;

            // Return back all the official segments joined together:
            return segments.Select(e => e.Segment);
        }

        private bool IsPointInRange(int p, int lower, int upper)
        {
            if (p < lower) return false;
            if (p > upper) return false;
            return true;
        }

        public struct CellState
        {
            public bool Visited;
            public LineSegmentRef lsiN;
            public LineSegmentRef lsiS;
            public LineSegmentRef lsiE;
            public LineSegmentRef lsiW;
        }

        public class LineSegmentRef
        {
            public LineSegment Segment;
        }
    }
}
