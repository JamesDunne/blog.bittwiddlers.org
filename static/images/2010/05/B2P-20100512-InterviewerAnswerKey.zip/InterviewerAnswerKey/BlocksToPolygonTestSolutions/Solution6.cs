﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class Solution6TransformAlgorithm : ITransformAlgorithm
    {
        public string AlgorithmName { get { return "Nested for-loops, longest lines, no orphaned areas"; } }

        public IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition)
        {
            ColumnState[] colstate = new ColumnState[map.Width];
            LineSegmentRef lsiN = null, lsiS = null;

            for (int y = 0; y < map.Height; ++y)
            {
                for (int x = 0; x < map.Width; ++x)
                {
                    // Check each of four cardinal directions for solid blocks:
                    var cur = new Point(x, y);

                    if (!map.IsSolid(cur))
                    {
                        // North:
                        if (IsPointInRange(cur.Y - 1, 0, map.Height - 1))
                        {
                            var tmp = new Point(cur.X, cur.Y - 1);
                            if (map.IsSolid(tmp))
                            {
                                if (lsiN != null)
                                {
                                    lsiN.Segment.End = new Point(tmp.X + 1, cur.Y);
                                }
                                else
                                {
                                    lsiN = new LineSegmentRef
                                    {
                                        Segment = new LineSegment(
                                            new Point(tmp.X, cur.Y),
                                            new Point(tmp.X + 1, cur.Y)
                                        )
                                    };
                                }
                            }
                            else
                            {
                                if (lsiN != null)
                                {
                                    yield return lsiN.Segment;
                                    lsiN = null;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (lsiN != null)
                        {
                            yield return lsiN.Segment;
                            lsiN = null;
                        }
                    }

                    // South:
                    if (!map.IsSolid(cur))
                    {
                        if (IsPointInRange(cur.Y + 1, 0, map.Height - 1))
                        {
                            var tmp = new Point(cur.X, cur.Y + 1);
                            if (map.IsSolid(tmp))
                            {
                                if (lsiS != null)
                                {
                                    lsiS.Segment.Begin = new Point(tmp.X + 1, tmp.Y);
                                }
                                else
                                {
                                    lsiS = new LineSegmentRef
                                    {
                                        Segment = new LineSegment(
                                            new Point(tmp.X + 1, tmp.Y),
                                            new Point(tmp.X, tmp.Y)
                                        )
                                    };
                                }
                            }
                            else
                            {
                                if (lsiS != null)
                                {
                                    yield return lsiS.Segment;
                                    lsiS = null;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (lsiS != null)
                        {
                            yield return lsiS.Segment;
                            lsiS = null;
                        }
                    }

                    // East:
                    if (!map.IsSolid(cur))
                    {
                        if (IsPointInRange(cur.X + 1, 0, map.Width - 1))
                        {
                            var tmp = new Point(cur.X + 1, cur.Y);
                            if (map.IsSolid(tmp))
                            {
                                if (colstate[x].lsiE != null)
                                {
                                    colstate[x].lsiE.Segment.End = new Point(tmp.X, tmp.Y + 1);
                                }
                                else
                                {
                                    colstate[x].lsiE = new LineSegmentRef
                                    {
                                        Segment = new LineSegment(
                                            new Point(tmp.X, tmp.Y),
                                            new Point(tmp.X, tmp.Y + 1)
                                        )
                                    };
                                }
                            }
                            else
                            {
                                if (colstate[x].lsiE != null)
                                {
                                    yield return colstate[x].lsiE.Segment;
                                    colstate[x].lsiE = null;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (colstate[x].lsiE != null)
                        {
                            yield return colstate[x].lsiE.Segment;
                            colstate[x].lsiE = null;
                        }
                    }

                    // West:
                    if (!map.IsSolid(cur))
                    {
                        if (IsPointInRange(cur.X - 1, 0, map.Width - 1))
                        {
                            var tmp = new Point(cur.X - 1, cur.Y);
                            if (map.IsSolid(tmp))
                            {
                                if (colstate[x].lsiW != null)
                                {
                                    colstate[x].lsiW.Segment.Begin = new Point(tmp.X + 1, tmp.Y + 1);
                                }
                                else
                                {
                                    colstate[x].lsiW = new LineSegmentRef
                                    {
                                        Segment = new LineSegment(
                                            new Point(tmp.X + 1, tmp.Y + 1),
                                            new Point(tmp.X + 1, tmp.Y)
                                        )
                                    };
                                }
                            }
                            else
                            {
                                if (colstate[x].lsiW != null)
                                {
                                    yield return colstate[x].lsiW.Segment;
                                    colstate[x].lsiW = null;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (colstate[x].lsiW != null)
                        {
                            yield return colstate[x].lsiW.Segment;
                            colstate[x].lsiW = null;
                        }
                    }
                }
            }

            // If the vertical walls ran off the bottom of the map, yield them back now:
            for (int x = 0; x < map.Width; ++x)
            {
                if (colstate[x].lsiE != null)
                {
                    yield return colstate[x].lsiE.Segment;
                    colstate[x].lsiE = null;
                }

                if (colstate[x].lsiW != null)
                {
                    yield return colstate[x].lsiW.Segment;
                    colstate[x].lsiW = null;
                }
            }

            // All done.
        }

        private bool IsPointInRange(int p, int lower, int upper)
        {
            if (p < lower) return false;
            if (p > upper) return false;
            return true;
        }

        public struct ColumnState
        {
            public LineSegmentRef lsiE;
            public LineSegmentRef lsiW;
        }

        public class LineSegmentRef
        {
            public LineSegment Segment;
        }
    }
}
