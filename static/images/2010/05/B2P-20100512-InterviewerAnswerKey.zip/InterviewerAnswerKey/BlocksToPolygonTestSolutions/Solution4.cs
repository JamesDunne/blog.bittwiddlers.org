﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class Solution4TransformAlgorithm : ITransformAlgorithm
    {
        public string AlgorithmName { get { return "Recursion Stack<T>, longest lines, no breaks, orphaned areas"; } }

        public IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition)
        {
            // Create a structure to mark which cells have been visited:
            CellState[,] state = new CellState[map.Height, map.Width];

            // Create a running list of longest line segments:
            List<LineSegmentRef> segments = new List<LineSegmentRef>(map.Height * map.Width);

            // Create a stack to hold the locations to visit for the flood-fill algorithm:
            Stack<Point> locsToVisit = new Stack<Point>(map.Height * map.Width);
            // Start with the starting position given:
            locsToVisit.Push(startingPosition);

            // Recurse until we run out of points to visit:
            while (locsToVisit.Count > 0)
            {
                // Get the point to visit:
                Point cur = locsToVisit.Pop();

                // If this position is already visited then continue to the next point:
                if (state[cur.Y, cur.X].Visited) continue;

                // Mark this point as having been visited:
                state[cur.Y, cur.X].Visited = true;

                // Check each of four cardinal directions for solid blocks:

                // North:
                if (IsPointInRange(cur.Y - 1, 0, map.Height - 1))
                {
                    var tmp = new Point(cur.X, cur.Y - 1);
                    if (map.IsSolid(tmp))
                    {
                        // Test whether to join two adjacent segments or to extend either side's adjacent segment:
                        if ((IsPointInRange(cur.X - 1, 0, map.Width - 1) && (state[cur.Y, cur.X - 1].lsiN != null)) &&
                            (IsPointInRange(cur.X + 1, 0, map.Width - 1) && (state[cur.Y, cur.X + 1].lsiN != null)))
                        {
                            // Joining two existing linesegments together:
                            var leftSeg = state[cur.Y, cur.X - 1].lsiN;
                            var rightSeg = state[cur.Y, cur.X + 1].lsiN;

                            // Replace references to rightSeg with leftSeg:
                            for (int i = cur.X + 1; i < map.Width; ++i)
                                if (state[cur.Y, i].lsiN == rightSeg)
                                    state[cur.Y, i].lsiN = leftSeg;

                            // Remove the segment from the official list:
                            segments.Remove(rightSeg);

                            leftSeg.Segment.End = rightSeg.Segment.End;
                            state[cur.Y, cur.X].lsiN = leftSeg;
                        }
                        else if (IsPointInRange(cur.X - 1, 0, map.Width - 1) && (state[cur.Y, cur.X - 1].lsiN != null))
                        {
                            // Extending a linesegment from the left:
                            (state[cur.Y, cur.X].lsiN = state[cur.Y, cur.X - 1].lsiN).Segment.End = new Point(tmp.X + 1, cur.Y);
                        }
                        else if (IsPointInRange(cur.X + 1, 0, map.Width - 1) && (state[cur.Y, cur.X + 1].lsiN != null))
                        {
                            // Extending a linesegment from the right:
                            (state[cur.Y, cur.X].lsiN = state[cur.Y, cur.X + 1].lsiN).Segment.Begin = new Point(tmp.X, cur.Y);
                        }
                        else
                        {
                            // No linesegments to the left or right, create a new one:
                            segments.Add(
                                state[cur.Y, cur.X].lsiN = new LineSegmentRef()
                                {
                                    Segment = new LineSegment(
                                        new Point(tmp.X, cur.Y),
                                        new Point(tmp.X + 1, cur.Y)
                                    )
                                }
                            );
                        }
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }

                // East:
                if (IsPointInRange(cur.X + 1, 0, map.Width - 1))
                {
                    var tmp = new Point(cur.X + 1, cur.Y);
                    if (map.IsSolid(tmp))
                    {
                        // Test whether to join two adjacent segments or to extend either side's adjacent segment:
                        if ((IsPointInRange(cur.Y - 1, 0, map.Height - 1) && (state[cur.Y - 1, cur.X].lsiE != null)) &&
                            (IsPointInRange(cur.Y + 1, 0, map.Height - 1) && (state[cur.Y + 1, cur.X].lsiE != null)))
                        {
                            // Joining two existing linesegments together:
                            var leftSeg = state[cur.Y - 1, cur.X].lsiE;
                            var rightSeg = state[cur.Y + 1, cur.X].lsiE;

                            // Replace references to rightSeg with leftSeg:
                            for (int i = cur.Y + 1; i < map.Height; ++i)
                                if (state[i, cur.X].lsiE == rightSeg)
                                    state[i, cur.X].lsiE = leftSeg;

                            // Remove the segment from the official list:
                            segments.Remove(rightSeg);

                            leftSeg.Segment.End = rightSeg.Segment.End;
                            state[cur.Y, cur.X].lsiE = leftSeg;
                        }
                        else if (IsPointInRange(cur.Y - 1, 0, map.Height - 1) && (state[cur.Y - 1, cur.X].lsiE != null))
                        {
                            // Extending a linesegment from the top:
                            (state[cur.Y, cur.X].lsiE = state[cur.Y - 1, cur.X].lsiE).Segment.End = new Point(tmp.X, tmp.Y + 1);
                        }
                        else if (IsPointInRange(cur.Y + 1, 0, map.Height - 1) && (state[cur.Y + 1, cur.X].lsiE != null))
                        {
                            // Extending a linesegment from the bottom:
                            (state[cur.Y, cur.X].lsiE = state[cur.Y + 1, cur.X].lsiE).Segment.Begin = new Point(tmp.X, tmp.Y);
                        }
                        else
                        {
                            segments.Add(
                                state[cur.Y, cur.X].lsiE = new LineSegmentRef()
                                {
                                    Segment = new LineSegment(
                                        new Point(tmp.X, tmp.Y),
                                        new Point(tmp.X, tmp.Y + 1)
                                    )
                                }
                            );
                        }
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }

                // South:
                if (IsPointInRange(cur.Y + 1, 0, map.Height - 1))
                {
                    var tmp = new Point(cur.X, cur.Y + 1);
                    if (map.IsSolid(tmp))
                    {
                        // Test whether to join two adjacent segments or to extend either side's adjacent segment:
                        if ((IsPointInRange(cur.X - 1, 0, map.Width - 1) && (state[cur.Y, cur.X - 1].lsiS != null)) &&
                            (IsPointInRange(cur.X + 1, 0, map.Width - 1) && (state[cur.Y, cur.X + 1].lsiS != null)))
                        {
                            // Joining two existing linesegments together:
                            var leftSeg = state[cur.Y, cur.X - 1].lsiS;
                            var rightSeg = state[cur.Y, cur.X + 1].lsiS;

                            // Replace references to rightSeg with leftSeg:
                            for (int i = cur.X - 1; i >= 0; --i)
                                if (state[cur.Y, i].lsiS == leftSeg)
                                    state[cur.Y, i].lsiS = rightSeg;

                            // Remove the segment from the official list:
                            segments.Remove(leftSeg);

                            rightSeg.Segment.End = leftSeg.Segment.End;
                            state[cur.Y, cur.X].lsiS = rightSeg;
                        }
                        else if (IsPointInRange(cur.X - 1, 0, map.Width - 1) && (state[cur.Y, cur.X - 1].lsiS != null))
                        {
                            // Extending a linesegment from the left:
                            (state[cur.Y, cur.X].lsiS = state[cur.Y, cur.X - 1].lsiS).Segment.Begin = new Point(tmp.X + 1, tmp.Y);
                        }
                        else if (IsPointInRange(cur.X + 1, 0, map.Width - 1) && (state[cur.Y, cur.X + 1].lsiS != null))
                        {
                            // Extending a linesegment from the right:
                            (state[cur.Y, cur.X].lsiS = state[cur.Y, cur.X + 1].lsiS).Segment.End = new Point(tmp.X, tmp.Y);
                        }
                        else
                        {
                            // No linesegments to the left or right, create a new one:
                            segments.Add(
                                state[cur.Y, cur.X].lsiS = new LineSegmentRef()
                                {
                                    Segment = new LineSegment(
                                        new Point(tmp.X + 1, tmp.Y),
                                        new Point(tmp.X, tmp.Y)
                                    )
                                }
                            );
                        }
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }

                // West:
                if (IsPointInRange(cur.X - 1, 0, map.Width - 1))
                {
                    var tmp = new Point(cur.X - 1, cur.Y);
                    if (map.IsSolid(tmp))
                    {
                        // Test whether to join two adjacent segments or to extend either side's adjacent segment:
                        if ((IsPointInRange(cur.Y - 1, 0, map.Height - 1) && (state[cur.Y - 1, cur.X].lsiW != null)) &&
                            (IsPointInRange(cur.Y + 1, 0, map.Height - 1) && (state[cur.Y + 1, cur.X].lsiW != null)))
                        {
                            // Joining two existing linesegments together:
                            var leftSeg = state[cur.Y - 1, cur.X].lsiW;
                            var rightSeg = state[cur.Y + 1, cur.X].lsiW;

                            // Replace references to rightSeg with leftSeg:
                            for (int i = cur.Y - 1; i >= 0; --i)
                                if (state[i, cur.X].lsiW == leftSeg)
                                    state[i, cur.X].lsiW = rightSeg;

                            // Remove the segment from the official list:
                            segments.Remove(leftSeg);

                            rightSeg.Segment.End = leftSeg.Segment.End;
                            state[cur.Y, cur.X].lsiW = rightSeg;
                        }
                        else if (IsPointInRange(cur.Y - 1, 0, map.Height - 1) && (state[cur.Y - 1, cur.X].lsiW != null))
                        {
                            // Extending a linesegment from the top:
                            (state[cur.Y, cur.X].lsiW = state[cur.Y - 1, cur.X].lsiW).Segment.Begin = new Point(tmp.X + 1, tmp.Y + 1);
                        }
                        else if (IsPointInRange(cur.Y + 1, 0, map.Height - 1) && (state[cur.Y + 1, cur.X].lsiW != null))
                        {
                            // Extending a linesegment from the bottom:
                            (state[cur.Y, cur.X].lsiW = state[cur.Y + 1, cur.X].lsiW).Segment.End = new Point(tmp.X + 1, tmp.Y);
                        }
                        else
                        {
                            segments.Add(
                                state[cur.Y, cur.X].lsiW = new LineSegmentRef()
                                {
                                    Segment = new LineSegment(
                                        new Point(tmp.X + 1, tmp.Y + 1),
                                        new Point(tmp.X + 1, tmp.Y)
                                    )
                                }
                            );
                        }
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }
            }

            state = null;
            locsToVisit = null;

            // Return back all the official segments joined together:
            return segments.Select(e => e.Segment);
        }

        private bool IsPointInRange(int p, int lower, int upper)
        {
            if (p < lower) return false;
            if (p > upper) return false;
            return true;
        }

        public struct CellState
        {
            public bool Visited;
            public LineSegmentRef lsiN;
            public LineSegmentRef lsiS;
            public LineSegmentRef lsiE;
            public LineSegmentRef lsiW;
        }

        public class LineSegmentRef
        {
            public LineSegment Segment;
        }
    }
}
