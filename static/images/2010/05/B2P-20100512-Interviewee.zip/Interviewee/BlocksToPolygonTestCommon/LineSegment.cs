﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public struct LineSegment
    {
        public Point Begin, End;

        public LineSegment(Point begin, Point end)
        {
            Begin = begin;
            End = end;
        }
    }
}
