﻿namespace BlocksToPolygonTest
{
    partial class PolygonDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pbInput = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pbOutput = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnBenchmark = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ddlSolution = new System.Windows.Forms.ComboBox();
            this.cbDisplayGrid = new System.Windows.Forms.CheckBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openGridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveGridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dlgOpen = new System.Windows.Forms.OpenFileDialog();
            this.dlgSave = new System.Windows.Forms.SaveFileDialog();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbInput)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pbInput);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(390, 403);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Input Map";
            // 
            // pbInput
            // 
            this.pbInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbInput.Location = new System.Drawing.Point(3, 16);
            this.pbInput.Name = "pbInput";
            this.pbInput.Size = new System.Drawing.Size(384, 384);
            this.pbInput.TabIndex = 0;
            this.pbInput.TabStop = false;
            this.pbInput.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbInput_MouseMove);
            this.pbInput.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbInput_MouseDown);
            this.pbInput.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbInput_MouseUp);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pbOutput);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(390, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(390, 403);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Output Polygon";
            // 
            // pbOutput
            // 
            this.pbOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbOutput.Location = new System.Drawing.Point(3, 16);
            this.pbOutput.Name = "pbOutput";
            this.pbOutput.Size = new System.Drawing.Size(384, 384);
            this.pbOutput.TabIndex = 0;
            this.pbOutput.TabStop = false;
            this.pbOutput.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbInput_MouseMove);
            this.pbOutput.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbInput_MouseDown);
            this.pbOutput.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbInput_MouseUp);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(780, 403);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnBenchmark);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.ddlSolution);
            this.panel2.Controls.Add(this.cbDisplayGrid);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(780, 24);
            this.panel2.TabIndex = 3;
            // 
            // btnBenchmark
            // 
            this.btnBenchmark.Location = new System.Drawing.Point(266, 4);
            this.btnBenchmark.Name = "btnBenchmark";
            this.btnBenchmark.Size = new System.Drawing.Size(75, 20);
            this.btnBenchmark.TabIndex = 3;
            this.btnBenchmark.Text = "Benchmark";
            this.btnBenchmark.UseVisualStyleBackColor = true;
            this.btnBenchmark.Click += new System.EventHandler(this.btnBenchmark_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(347, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Solution:";
            // 
            // ddlSolution
            // 
            this.ddlSolution.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ddlSolution.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlSolution.FormattingEnabled = true;
            this.ddlSolution.Location = new System.Drawing.Point(401, 2);
            this.ddlSolution.Name = "ddlSolution";
            this.ddlSolution.Size = new System.Drawing.Size(376, 21);
            this.ddlSolution.TabIndex = 1;
            this.ddlSolution.SelectedIndexChanged += new System.EventHandler(this.ddlSolution_SelectedIndexChanged);
            // 
            // cbDisplayGrid
            // 
            this.cbDisplayGrid.AutoSize = true;
            this.cbDisplayGrid.Checked = true;
            this.cbDisplayGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbDisplayGrid.Location = new System.Drawing.Point(13, 4);
            this.cbDisplayGrid.Name = "cbDisplayGrid";
            this.cbDisplayGrid.Size = new System.Drawing.Size(82, 17);
            this.cbDisplayGrid.TabIndex = 0;
            this.cbDisplayGrid.Text = "Display Grid";
            this.cbDisplayGrid.UseVisualStyleBackColor = true;
            this.cbDisplayGrid.CheckedChanged += new System.EventHandler(this.cbDisplayGrid_CheckedChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(780, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openGridToolStripMenuItem,
            this.saveGridToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // openGridToolStripMenuItem
            // 
            this.openGridToolStripMenuItem.Name = "openGridToolStripMenuItem";
            this.openGridToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.openGridToolStripMenuItem.Text = "&Open Grid...";
            this.openGridToolStripMenuItem.Click += new System.EventHandler(this.openGridToolStripMenuItem_Click);
            // 
            // saveGridToolStripMenuItem
            // 
            this.saveGridToolStripMenuItem.Name = "saveGridToolStripMenuItem";
            this.saveGridToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveGridToolStripMenuItem.Text = "&Save Grid...";
            this.saveGridToolStripMenuItem.Click += new System.EventHandler(this.saveGridToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(149, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // dlgOpen
            // 
            this.dlgOpen.DefaultExt = "map";
            this.dlgOpen.FileName = "InputGrid.map";
            this.dlgOpen.Filter = "Binary map file|*.map|All files|*.*";
            this.dlgOpen.Title = "Open input map";
            // 
            // dlgSave
            // 
            this.dlgSave.DefaultExt = "map";
            this.dlgSave.FileName = "InputGrid.map";
            this.dlgSave.Filter = "Binary map file|*.map|All files|*.*";
            this.dlgSave.Title = "Save input map";
            // 
            // PolygonDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 451);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "PolygonDisplay";
            this.Text = "Grid To Polygon";
            this.Load += new System.EventHandler(this.PolygonDisplay_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbInput)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pbInput;
        private System.Windows.Forms.PictureBox pbOutput;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox cbDisplayGrid;
        private System.Windows.Forms.ComboBox ddlSolution;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openGridToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveGridToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog dlgOpen;
        private System.Windows.Forms.SaveFileDialog dlgSave;
        private System.Windows.Forms.Button btnBenchmark;
    }
}

