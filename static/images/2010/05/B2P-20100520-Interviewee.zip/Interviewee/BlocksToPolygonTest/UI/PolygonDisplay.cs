﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BlocksToPolygonTest
{
    public partial class PolygonDisplay : Form
    {
        private const int width = 64;
        private const int height = 64;

        public PolygonDisplay()
        {
            InitializeComponent();

            // Autosize the groupboxes and image containers based on map height/width:
            this.pbInput.Size = new System.Drawing.Size(width * CellSize, height * CellSize);
            this.pbOutput.Size = new System.Drawing.Size(width * CellSize, height * CellSize);
            this.groupBox1.Size = new System.Drawing.Size(width * CellSize + 6, height * CellSize + 19);
            this.groupBox2.Size = new System.Drawing.Size(width * CellSize + 6, height * CellSize + 19);
            this.groupBox2.Location = new System.Drawing.Point(width * CellSize + 6, 0);
            this.panel1.Size = new System.Drawing.Size(width * CellSize * 2 + 12, height * CellSize + 19);
            this.panel2.Size = new System.Drawing.Size(width * CellSize * 2 + 12, 24);
            this.ClientSize = new System.Drawing.Size(width * CellSize * 2 + 12, height * CellSize + 67);

            // Create a Bitmap to render the input grid to:
            inpgrdBitmap = new Bitmap(pbInput.Width, pbInput.Height);
            // Create a Bitmap to render the output polygon outline to:
            outgrdBitmap = new Bitmap(pbOutput.Width, pbOutput.Height);

            map = new RectangularMap(width, height);

            // Fill the map as solid by default and carve out empty rooms:
            map.FillRectangle(0, 0, width, height, true);

            // Carve out room:
            map.FillRectangle(1, 1, 11, 7, false);
            map.FillRectangle(13, 1, 8, 7, false);
            map.DrawHLine(11, 4, 2, false);
            map.DrawVLine(16, 7, 2, false);
            map.FillRectangle(13, 9, 8, 8, false);
            map.FillRectangle(15, 12, 3, 3, true);

            startingPosition = new Point(2, 2);

            algorithms = new ITransformAlgorithm[10];
            algorithms[0] = new Solution8TransformAlgorithm();
            algorithms[1] = new Solution7TransformAlgorithm();
            algorithms[2] = new Solution6TransformAlgorithm();
            algorithms[3] = new Solution5TransformAlgorithm();
            algorithms[4] = new Solution5aTransformAlgorithm();
            algorithms[5] = new Solution4TransformAlgorithm();
            algorithms[6] = new Solution3TransformAlgorithm();
            algorithms[7] = new Solution2TransformAlgorithm();
            algorithms[8] = new Solution1TransformAlgorithm();
            algorithms[9] = new DeveloperTransformAlgorithm();

            algidx = 9;
        }

        private void PolygonDisplay_Load(object sender, EventArgs e)
        {
            ddlSolution.Items.Clear();
            ddlSolution.Items.AddRange((from alg in algorithms select alg.AlgorithmName).ToArray());
            ddlSolution.SelectedIndex = algidx;

            RenderDisplays(this.map);
        }

        private ITransformAlgorithm[] algorithms;
        private int algidx;

        /// <summary>
        /// Each cell is a square of 8m by 8m (meters).
        /// </summary>
        public const int CellSize = 8;
        private const int HalfCellSize = 3;

        private RectangularMap map;
        private Point startingPosition;

        private Bitmap inpgrdBitmap;
        private Bitmap outgrdBitmap;

        private bool displayGrid = true;

        private void RenderDisplays(RectangularMap map)
        {
            using (var gr = Graphics.FromImage(inpgrdBitmap))
            {
                gr.Clear(Color.White);

                // Draw only the solid-filled black cells in the inputGrid:
                gr.FillRectangles(
                    Brushes.Black,
                    (
                        from y in Enumerable.Range(0, map.Height)
                        from x in Enumerable.Range(0, map.Width)
                        let pnt = new Point(x, y)
                        where map.IsSolid(pnt)
                        select new Rectangle(x * CellSize, y * CellSize, CellSize, CellSize)
                    ).ToArray()
                );

                // Draw the starting position as a red X:
                var xPen = new Pen(Color.OrangeRed, 2.0f);
                gr.DrawLines(xPen, new Point[2] { new Point(startingPosition.X * CellSize, startingPosition.Y * CellSize), new Point(startingPosition.X * CellSize + CellSize, startingPosition.Y * CellSize + CellSize) });
                gr.DrawLines(xPen, new Point[2] { new Point(startingPosition.X * CellSize, startingPosition.Y * CellSize + CellSize), new Point(startingPosition.X * CellSize + CellSize, startingPosition.Y * CellSize) });

                if (this.displayGrid)
                {
                    // Render a grid of red lines over the solid and empty cells:
                    for (int y = 0; y <= map.Height; ++y)
                        gr.DrawLine(
                            Pens.DarkRed,
                            new Point(0 * CellSize, y * CellSize),
                            new Point(map.Width * CellSize, y * CellSize)
                        );
                    for (int x = 0; x <= map.Width; ++x)
                        gr.DrawLine(
                            Pens.DarkRed,
                            new Point(x * CellSize, 0),
                            new Point(x * CellSize, map.Height * CellSize)
                        );
                }
            }
            // Assign the Bitmap to the input grid's PictureBox:
            pbInput.Image = inpgrdBitmap;

            using (var gr = Graphics.FromImage(outgrdBitmap))
            {
                gr.Clear(Color.White);

                if (this.displayGrid)
                {
                    // Render a grid of red lines:
                    for (int y = 0; y <= map.Height; ++y)
                        gr.DrawLine(
                            Pens.Green,
                            new Point(0, y * CellSize),
                            new Point(map.Width * CellSize, y * CellSize)
                        );
                    for (int x = 0; x <= map.Width; ++x)
                        gr.DrawLine(
                            Pens.Green,
                            new Point(x * CellSize, 0),
                            new Point(x * CellSize, map.Height * CellSize)
                        );
                }

                // Draw the wall outline line segments:
                var wallPen = new Pen(Color.Navy, 2.0f);
                foreach (var ls in algorithms[algidx].TransformBlocksToLineSegments(map, startingPosition))
                {
                    // Draw the line segment itself:
                    gr.DrawLines(wallPen, new Point[2] { new Point(ls.Begin.X * CellSize, ls.Begin.Y * CellSize), new Point(ls.End.X * CellSize, ls.End.Y * CellSize) });

                    // Draw the line normal:
                    if (ls.End.X > ls.Begin.X)
                    {
                        int hx = (ls.End.X * CellSize - ls.Begin.X * CellSize) / 2 + ls.Begin.X * CellSize;
                        gr.DrawLine(wallPen, new Point(hx, ls.Begin.Y * CellSize), new Point(hx, ls.Begin.Y * CellSize + HalfCellSize));
                    }
                    else if (ls.End.X < ls.Begin.X)
                    {
                        int hx = (ls.Begin.X * CellSize - ls.End.X * CellSize) / 2 + ls.End.X * CellSize;
                        gr.DrawLine(wallPen, new Point(hx, ls.Begin.Y * CellSize), new Point(hx, ls.Begin.Y * CellSize - HalfCellSize));
                    }
                    else if (ls.End.Y > ls.Begin.Y)
                    {
                        int hy = (ls.End.Y * CellSize - ls.Begin.Y * CellSize) / 2 + ls.Begin.Y * CellSize;
                        gr.DrawLine(wallPen, new Point(ls.Begin.X * CellSize, hy), new Point(ls.Begin.X * CellSize - HalfCellSize, hy));
                    }
                    else if (ls.End.Y < ls.Begin.Y)
                    {
                        int hy = (ls.Begin.Y * CellSize - ls.End.Y * CellSize) / 2 + ls.End.Y * CellSize;
                        gr.DrawLine(wallPen, new Point(ls.Begin.X * CellSize, hy), new Point(ls.Begin.X * CellSize + HalfCellSize, hy));
                    }
                }

                // Draw the starting position as a red X:
                var xPen = new Pen(Color.OrangeRed, 2.0f);
                gr.DrawLines(xPen, new Point[2] { new Point(startingPosition.X * CellSize, startingPosition.Y * CellSize), new Point(startingPosition.X * CellSize + CellSize, startingPosition.Y * CellSize + CellSize) });
                gr.DrawLines(xPen, new Point[2] { new Point(startingPosition.X * CellSize, startingPosition.Y * CellSize + CellSize), new Point(startingPosition.X * CellSize + CellSize, startingPosition.Y * CellSize) });
            }
            pbOutput.Image = outgrdBitmap;
        }

        private void RefreshDisplays(RectangularMap m)
        {
            RenderDisplays(m);
            pbInput.Refresh();
            pbOutput.Refresh();
        }

        private MouseButtons btnsHeld = MouseButtons.None;
        private RectangularMap tmpMap = null;
        private int tx1, ty1;

        private void pbInput_MouseDown(object sender, MouseEventArgs e)
        {
            btnsHeld |= e.Button;
            tx1 = e.X / CellSize;
            ty1 = e.Y / CellSize;
        }

        private void pbInput_MouseMove(object sender, MouseEventArgs e)
        {
            if ((btnsHeld & MouseButtons.Left) == MouseButtons.Left)
            {
                tmpMap = new RectangularMap(map);

                int x2 = e.X / CellSize;
                int y2 = e.Y / CellSize;
                if (x2 >= map.Width) x2 = map.Width - 1;
                if (y2 >= map.Height) y2 = map.Height - 1;

                int x1 = tx1;
                int y1 = ty1;
                if (x2 < x1)
                {
                    int temp = x2;
                    x2 = x1;
                    x1 = temp;
                }
                if (y2 < y1)
                {
                    int temp = y2;
                    y2 = y1;
                    y1 = temp;
                }

                // Alter the input map:
                tmpMap.FillRectangle(x1, y1, x2 - x1 + 1, y2 - y1 + 1, false);

                // Update the display:
                RefreshDisplays(tmpMap);
            }
            else if ((btnsHeld & MouseButtons.Right) == MouseButtons.Right)
            {
                tmpMap = new RectangularMap(map);

                int x2 = e.X / CellSize;
                int y2 = e.Y / CellSize;
                if (x2 >= map.Width) x2 = map.Width - 1;
                if (y2 >= map.Height) y2 = map.Height - 1;

                int x1 = tx1;
                int y1 = ty1;
                if (x2 < x1)
                {
                    int temp = x2;
                    x2 = x1;
                    x1 = temp;
                }
                if (y2 < y1)
                {
                    int temp = y2;
                    y2 = y1;
                    y1 = temp;
                }

                // Alter the input map:
                tmpMap.FillRectangle(x1, y1, x2 - x1 + 1, y2 - y1 + 1, true);

                // Update the display:
                RefreshDisplays(tmpMap);
            }
        }

        private void pbInput_MouseUp(object sender, MouseEventArgs e)
        {
            btnsHeld &= ~e.Button;

            // Make the new rectangle permanent:
            if (tmpMap != null) map = tmpMap;
            tmpMap = null;
        }

        private void cbDisplayGrid_CheckedChanged(object sender, EventArgs e)
        {
            this.displayGrid = ((CheckBox)sender).Checked;

            // Update the display:
            RefreshDisplays(map);
        }

        private void ddlSolution_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.algidx = ((ComboBox)sender).SelectedIndex;

            // Update the display:
            RefreshDisplays(map);
        }

        private void openGridToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var result = dlgOpen.ShowDialog();
            if (result != DialogResult.OK) return;

            byte[] mapData = File.ReadAllBytes(dlgOpen.FileName);
            this.map = new RectangularMap(width, height, new RectangularMap(mapData));

            // Update the display:
            RefreshDisplays(map);
        }

        private void saveGridToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var result = dlgSave.ShowDialog();
            if (result != DialogResult.OK) return;

            // Serialize the map to the file:
            File.WriteAllBytes(dlgSave.FileName, this.map.Serialize());
        }

        private void btnBenchmark_Click(object sender, EventArgs e)
        {
#if false
            // Start a stopwatch to time the algorithm's performance across 500 runs:
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();
            for (int i = 0; i < 500; ++i)
            {
                foreach (var ls in algorithms[algidx].TransformBlocksToLineSegments(map, startingPosition))
                {
                }
            }
            sw.Stop();
            
            // Display the results:
            double elSec = sw.Elapsed.TotalMilliseconds / 500d;
            string display = String.Format("Average time per run: {0} ms", elSec);
            MessageBox.Show(this, display, algorithms[algidx].AlgorithmName, MessageBoxButtons.OK, MessageBoxIcon.Information);
#else
            // Time all algorithms in succession:
            System.Diagnostics.Stopwatch[] timers = new System.Diagnostics.Stopwatch[algorithms.Length];
            for (int i = 0; i < algorithms.Length; ++i)
            {
                // Incur the initial JIT cost:
                foreach (var ls in algorithms[i].TransformBlocksToLineSegments(map, startingPosition)) { }

                // Start a stopwatch to time the algorithm's performance across 500 runs:
                timers[i] = System.Diagnostics.Stopwatch.StartNew();
                for (int k = 0; k < 500; ++k)
                {
                    foreach (var ls in algorithms[i].TransformBlocksToLineSegments(map, startingPosition))
                    {
                    }
                }
                timers[i].Stop();
            }

            string[] results = timers
                // Join the Timer with its Algorithm:
                .Select((t,i) => new { Timer = t, Algorithm = algorithms[i] })
                // Order by time taken ascending:
                .OrderBy(k => k.Timer.ElapsedTicks)
                // Format a result line:
                .Select(k => String.Format("{0:0.0000} ms for {1}", k.Timer.Elapsed.TotalMilliseconds / 500.000d, k.Algorithm.AlgorithmName))
                // Convert the whole thing into a string[] for String.Join:
                .ToArray();
            
            MessageBox.Show(this, String.Join(Environment.NewLine, results), algorithms[algidx].AlgorithmName, MessageBoxButtons.OK, MessageBoxIcon.Information);
#endif
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
