﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;

namespace Linq
{
    public class LinqHTMLFormatter : LinqSyntaxExpressionFormatter
    {
        protected override Expression VisitQuery(Expression query)
        {
            WriteComment("// C# LINQ query:");
            WriteKeyword("var");
            WriteWhitespace(" ");
            WriteIdentifier("query");
            WriteWhitespace(" ");
            WriteOperator("=");
            Indent();
            WriteNewline();
            Expression ret = this.Visit(query);
            Unindent();
            WriteOperator(";");
            return ret;
        }

        public override void WriteFormat(Expression query, System.IO.TextWriter tw)
        {
            Reset();

            VisitQuery(query);

            foreach (var tok in output)
            {
                switch (tok.TokenType)
                {
                    case TokenType.Newline:
                        tw.Write("\r\n" + String.Concat(Enumerable.Repeat<string>(indentString, tok.IndentationDepth.Value).ToArray()));
                        break;
                    case TokenType.Comment:
                        tw.Write(String.Concat(
                            "<span class=\"csharp_comment\">",
                            HttpUtility.HtmlEncode(tok.Text),
                            "</span>"
                        ));
                        break;
                    case TokenType.Keyword:
                        tw.Write(String.Concat(
                            "<span class=\"csharp_keyword\">",
                            HttpUtility.HtmlEncode(tok.Text),
                            "</span>"
                        ));
                        break;
                    case TokenType.ValueType:
                        tw.Write(String.Concat(
                            "<span class=\"csharp_valuetype\">",
                            HttpUtility.HtmlEncode(tok.Text),
                            "</span>"
                        ));
                        break;
                    case TokenType.ClassType:
                        tw.Write(String.Concat(
                            "<span class=\"csharp_classtype\">",
                            HttpUtility.HtmlEncode(tok.Text),
                            "</span>"
                        ));
                        break;
                    case TokenType.InterfaceType:
                        tw.Write(String.Concat(
                            "<span class=\"csharp_classtype\">",
                            HttpUtility.HtmlEncode(tok.Text),
                            "</span>"
                        ));
                        break;
                    case TokenType.Identifier:
                        tw.Write(String.Concat(
                            "<span class=\"csharp_identifier\">",
                            HttpUtility.HtmlEncode(tok.Text),
                            "</span>"
                        ));
                        break;
                    case TokenType.ConstantString:
                        tw.Write(String.Concat(
                            "<span class=\"csharp_string\">",
                            HttpUtility.HtmlEncode(tok.Text),
                            "</span>"
                        ));
                        break;
                    case TokenType.ConstantIntegral:
                    case TokenType.Unformatted:
                    default:
                        tw.Write(HttpUtility.HtmlEncode(tok.Text));
                        break;
                }
            }
        }
    }
}