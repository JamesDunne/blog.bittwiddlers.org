﻿// C# LINQ syntax Expression formatter.
// (c) 2010 James S. Dunne
//
// I am calling this "Good Enough" for now. It is intended only for display purposes, not for creating compilable
// C# syntax.
//
// Known caveats:
// * `select` clauses may be missing in certain circumstances.
// * `from` clauses may be missing in certain circumstances.
// * `select` clauses may be followed by `where` clauses which is invalid in LINQ syntax.
// * `orderby` clauses may be followed by `select` clauses which is invalid in LINQ syntax.
// * Most constant value types are not supported for display purposes.
// * group X by Y into Z clause is not fully supported.
//
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Linq
{
    /// <summary>
    /// A lambda expression formatter which attempts to format the expression tree back into
    /// C# LINQ syntax.
    /// </summary>
    public class LinqSyntaxExpressionFormatter : ExpressionVisitor
    {
        protected void Reset()
        {
            InitializeWriter();
            state = new Stack<VisitorState>();
            state.Push(new VisitorState());
        }

        protected virtual Expression VisitQuery(Expression query)
        {
            return this.Visit(query);
        }

        /// <summary>
        /// Formats a LINQ query expression into C# LINQ syntax.
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public virtual string Format(Expression query)
        {
            StringBuilder sb = new StringBuilder();
            using (StringWriter sw = new StringWriter(sb))
            {
                WriteFormat(query, sw);
                sw.Flush();
            }
            return sb.ToString();
        }

        /// <summary>
        /// Writes the LINQ query to the TextWriter.
        /// </summary>
        /// <param name="query"></param>
        /// <param name="tw"></param>
        public virtual void WriteFormat(Expression query, TextWriter tw)
        {
            Reset();

            VisitQuery(query);

            foreach (var tok in output)
            {
                switch (tok.TokenType) {
                    case TokenType.Newline:
                        tw.Write("\r\n" + String.Concat(Enumerable.Repeat<string>(indentString, tok.IndentationDepth.Value).ToArray()));
                        break;
                    default:
                        tw.Write(tok.Text);
                        break;
                }
            }
        }

        /// <summary>
        /// Temporary recursion state.
        /// </summary>
        protected class VisitorState
        {
            public bool displayLambdaParameters = true;
            public bool wroteSelect = false;
            public bool topLevel = true;

            public VisitorState()
            {
            }

            public VisitorState(VisitorState ns)
            {
                this.displayLambdaParameters = ns.displayLambdaParameters;
                this.wroteSelect = ns.wroteSelect;
                this.topLevel = ns.topLevel;
            }
        }

        protected Stack<VisitorState> state;
        /// <summary>
        /// Get the current state.
        /// </summary>
        /// <returns></returns>
        protected VisitorState GetState()
        {
            return state.Peek();
        }
        /// <summary>
        /// Restore the last state.
        /// </summary>
        /// <returns></returns>
        protected VisitorState RestoreState()
        {
            return state.Pop();
        }
        /// <summary>
        /// Save this current state. Can be recovered with RestoreState().
        /// </summary>
        /// <param name="st"></param>
        /// <returns></returns>
        protected VisitorState PushState(params Action<VisitorState>[] st)
        {
            VisitorState ns = new VisitorState(GetState());
            foreach (var act in st) act(ns);
            state.Push(ns);
            return ns;
        }
        /// <summary>
        /// Update this current state.
        /// </summary>
        /// <param name="st"></param>
        /// <returns></returns>
        protected VisitorState UpdateState(params Action<VisitorState>[] st)
        {
            VisitorState ns = GetState();
            foreach (var act in st) act(ns);
            return ns;
        }

        #region Virtual writer methods

        protected enum TokenType
        {
            Unformatted,
            Whitespace,
            Comment,
            Newline,
            Keyword,
            Identifier,
            Operator,
            ClassType,
            ValueType,
            InterfaceType,
            ConstantIntegral,
            ConstantString,
        }

        [DebuggerDisplay("{Text}, {IndentationDepth}")]
        protected class OutputToken
        {
            public string Text { get; set; }
            public TokenType TokenType { get; set; }
            public int? IndentationDepth { get; set; }

            public OutputToken(string text)
            {
                this.Text = text;
                this.TokenType = TokenType.Unformatted;
                this.IndentationDepth = null;
            }

            public OutputToken(string text, int? depth)
            {
                this.Text = text;
                this.TokenType = TokenType.Unformatted;
                this.IndentationDepth = depth;
            }

            public OutputToken(string text, TokenType type)
            {
                this.Text = text;
                this.TokenType = type;
                this.IndentationDepth = null;
            }

            public OutputToken(string text, TokenType type, int? depth)
            {
                this.Text = text;
                this.TokenType = type;
                this.IndentationDepth = depth;
            }
        }
        protected List<OutputToken> output;
        protected int indentLevel = 0;
        protected string indentString = "     ";

        protected virtual void InitializeWriter()
        {
            output = new List<OutputToken>();
            indentLevel = 0;
            writeIndex = -1;
        }

        private int writeIndex = -1;

        protected int GetWriteIndex()
        {
            return this.output.Count;
        }

        protected void SetWriteIndex(int idx)
        {
            this.writeIndex = idx;
        }

        protected void SetWriteAppend()
        {
            this.writeIndex = -1;
        }

        protected void Output(OutputToken tok)
        {
            if (this.writeIndex == -1)
                this.output.Add(tok);
            else
            {
                this.output.Insert(this.writeIndex, tok);
                ++this.writeIndex;
            }
        }

        protected void Output(string text)
        {
            Output(new OutputToken(text));
        }

        protected void Output(string text, TokenType type)
        {
            Output(new OutputToken(text, type));
        }

        protected void OutputWithDepth(string text, TokenType type, int depth)
        {
            Output(new OutputToken(text, type, depth));
        }

        /// <summary>
        /// Writes whitespace characters to the output.
        /// </summary>
        /// <param name="ws"></param>
        protected virtual void WriteWhitespace(string ws) { Output(ws, TokenType.Whitespace); }
        /// <summary>
        /// Increase the indentation level for the next line.
        /// </summary>
        protected virtual void Indent() { ++indentLevel; }
        /// <summary>
        /// Decrease the indentation level for the next line.
        /// </summary>
        protected virtual void Unindent() { --indentLevel; }
        /// <summary>
        /// Writes a new line to the output followed by the indentation string.
        /// </summary>
        protected virtual void WriteNewline()
        {
            OutputWithDepth("\r\n", TokenType.Newline, indentLevel);
        }

        /// <summary>
        /// Writes a C# comment to the output.
        /// </summary>
        /// <param name="cm">Comment text, must be a // single line comment or be a /* block comment */ form.</param>
        protected virtual void WriteComment(string cm) { Output(cm, TokenType.Comment); WriteNewline(); }
        /// <summary>
        /// Writes operator characters to the output, such as parentheses and other non-alphanumeric/non-whitespace characters.
        /// </summary>
        /// <param name="op"></param>
        protected virtual void WriteOperator(string op) { Output(op, TokenType.Operator); }
        /// <summary>
        /// Writes a C# keyword to the output.
        /// </summary>
        /// <param name="kw"></param>
        protected virtual void WriteKeyword(string kw) { Output(kw, TokenType.Keyword); }
        /// <summary>
        /// Writes the name of a type to the output. It will be formatted as a C# primitive type name if applicable.
        /// </summary>
        /// <param name="ty"></param>
        protected virtual void WriteType(Type ty) { Output(ty.GetCSharpDisplayName(), ty.IsValueType ? TokenType.ValueType : ty.IsInterface ? TokenType.InterfaceType : TokenType.ClassType); }
        /// <summary>
        /// Writes a C# identifier to the output.
        /// </summary>
        /// <param name="id"></param>
        protected virtual void WriteIdentifier(string id) { Output(id, TokenType.Identifier); }
        /// <summary>
        /// Writes a C# constant value to the output.
        /// </summary>
        /// <param name="vType"></param>
        /// <param name="value"></param>
        protected virtual void WriteValue(Type vType, object value)
        {
            if (vType.IsPrimitive)
            {
                Output(value.ToString(), TokenType.ConstantIntegral);
            }
            else if (vType == typeof(string))
            {
                string strRep = String.Concat("\"", ((string)value).Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t"), "\"");
                Output(strRep, TokenType.ConstantString);
            }
            else
            {
                // TODO: other constant types for display here!
                Output(String.Concat("{", value.ToString(), "}"), TokenType.Unformatted);
            }
        }

        #endregion

        #region Visitor methods

        private Expression VisitSource(Expression e, Expression fromVar)
        {
            if (e.NodeType == ExpressionType.Constant)
            {
                WriteKeyword("from");
                WriteWhitespace(" ");
                this.Visit(fromVar);
                WriteWhitespace(" ");
                WriteKeyword("in");
                WriteWhitespace(" ");
                this.VisitConstant((ConstantExpression)e);
                return e;
            }
            else
            {
                return this.Visit(e);
            }
        }

        private void WriteExpressionListCommaDelimited(ReadOnlyCollection<Expression> args)
        {
            for (int i = 0; i < args.Count; ++i)
            {
                this.Visit(args[i]);
                if (i < args.Count - 1)
                {
                    WriteOperator(",");
                    WriteWhitespace(" ");
                }
            }
        }

        private Expression VisitSubquery(Expression e)
        {
            bool nontrivial = (e.NodeType != ExpressionType.Constant);
            if (nontrivial)
            {
                WriteOperator("(");
                Indent();
                WriteNewline();
            }
            PushState(x => x.wroteSelect = false, x => x.topLevel = true);
            this.Visit(e);
            if (nontrivial)
            {
                Unindent();
                WriteNewline();
                WriteOperator(")");
            }
            RestoreState();
            return e;
        }

        protected override Expression VisitMethodCall(MethodCallExpression m)
        {
            if ((m.Method.DeclaringType != typeof(Queryable)) && (m.Method.DeclaringType != typeof(Enumerable)))
            {
                this.Visit(m.Object);
                if (m.Object.Type.IsArray && (m.Method.Name == "get_Item"))
                {
                    WriteOperator("[");
                    WriteExpressionListCommaDelimited(m.Arguments);
                    WriteOperator("]");
                }
                else if (m.Object.Type.IsGenericType && (m.Object.Type.Name == "List`1") && (m.Method.Name == "get_Item"))
                {
                    WriteOperator("[");
                    WriteExpressionListCommaDelimited(m.Arguments);
                    WriteOperator("]");
                }
                else
                {
                    WriteOperator(".");
                    WriteIdentifier(m.Method.Name);
                    WriteOperator("(");
                    WriteExpressionListCommaDelimited(m.Arguments);
                    WriteOperator(")");
                }
                return m;
            }

            NewExpression ne;
            LambdaExpression le;
            Expression fromVar, joinVar;
            VisitorState tmp;
            bool isTopLevel = true;

            switch (m.Method.Name)
            {
                case "Select":
                    fromVar = DiscoverFromParameter(m.Arguments[1]);
                    isTopLevel = GetState().topLevel;
                    UpdateState(x => x.topLevel = false);

                    this.VisitSource(m.Arguments[0], fromVar);

                    if ((!isTopLevel) && ((ne = GetQuotedLambdaNew(m.Arguments[1])) != null) && (ne.Members.Count == 2))
                    {
                        // TODO: test all cases!
                        WriteNewline();
                        WriteKeyword("let");
                        WriteWhitespace(" ");
                        WriteIdentifier(ne.Members[1].Name.RemoveIfStartsWith("get_"));
                        WriteWhitespace(" ");
                        WriteOperator("=");
                        WriteWhitespace(" ");
                        this.Visit(ne.Arguments[1]);
                    }
                    else
                    {
                        WriteNewline();
                        WriteKeyword("select");
                        WriteWhitespace(" ");
                        PushState(x => x.displayLambdaParameters = false);
                        this.Visit(m.Arguments[1]);
                        RestoreState();
                        UpdateState(x => x.wroteSelect = true);
                    }

                    break;
                case "SelectMany":
                    fromVar = DiscoverFromParameter(m.Arguments[1]);
                    isTopLevel = GetState().topLevel;
                    UpdateState(x => x.topLevel = false);

                    this.VisitSource(m.Arguments[0], fromVar);

                    WriteWhitespace(" ");
                    // or WriteNewline();
                    WriteKeyword("from");
                    WriteWhitespace(" ");
                    this.Visit(DiscoverJoinFromParameter(m.Arguments[2]));
                    WriteWhitespace(" ");
                    WriteKeyword("in");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    this.Visit(m.Arguments[1]);
                    RestoreState();

                    le = GetQuotedLambda(m.Arguments[2]);
                    if (le != null)
                    {
                        if (le.Body.NodeType != ExpressionType.New)
                        {
                            WriteNewline();
                            WriteKeyword("select");
                            WriteWhitespace(" ");
                            this.Visit(le.Body);
                            UpdateState(x => x.wroteSelect = true);
                        }
                        else if (!(ne = (NewExpression)le.Body).Members[0].Name.StartsWith("get_<>h__TransparentIdentifier"))
                        {
                            WriteNewline();
                            WriteKeyword("select");
                            WriteWhitespace(" ");
                            PushState(x => x.displayLambdaParameters = false);
                            this.VisitNew(ne);
                            RestoreState();
                            UpdateState(x => x.wroteSelect = true);
                        }
                    }
                    break;
                case "Where":
                    fromVar = DiscoverFromParameter(m.Arguments[1]);
                    isTopLevel = GetState().topLevel;
                    UpdateState(x => x.topLevel = false);

                    int injectPoint = GetWriteIndex();

                    this.VisitSource(m.Arguments[0], fromVar);

                    tmp = GetState();
                    // If we wrote a select clause for the source query, then we need to
                    // wrap the source query in a from clause:
                    if (tmp.wroteSelect)
                    {
                        // Go back to before the source query expressions were written and
                        // surround them with `from x in (...)`:
                        SetWriteIndex(injectPoint);
                        WriteKeyword("from");
                        WriteWhitespace(" ");
                        this.Visit(fromVar);
                        WriteWhitespace(" ");
                        WriteKeyword("in");
                        WriteWhitespace(" ");
                        WriteOperator("(");
                        WriteNewline();
                        // Go back and adjust the indentation level for those tokens:
                        for (int i = injectPoint; i < output.Count; ++i)
                        {
                            if (!output[i].IndentationDepth.HasValue) continue;
                            ++output[i].IndentationDepth;
                        }
                        // Set the write pointer back into append mode:
                        SetWriteAppend();
                        WriteNewline();
                        WriteOperator(")");
                        // Clear the flag that indicates that this query has written a `select` clause because
                        // we've effectively created a new query.
                        tmp.wroteSelect = false;
                    }

                    WriteNewline();
                    WriteKeyword("where");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    this.Visit(m.Arguments[1]);
                    RestoreState();

                    if (isTopLevel && !tmp.wroteSelect)
                    {
                        WriteNewline();
                        WriteKeyword("select");
                        WriteWhitespace(" ");
                        this.Visit(fromVar);
                        UpdateState(x => x.wroteSelect = true);
                    }
                    break;
                case "Join":
                    fromVar = DiscoverFromParameter(m.Arguments[2]);
                    isTopLevel = GetState().topLevel;
                    UpdateState(x => x.topLevel = false);

                    this.VisitSource(m.Arguments[0], fromVar);

                    tmp = GetState();

                    WriteNewline();
                    WriteKeyword("join");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    joinVar = DiscoverJoinFromParameter(m.Arguments[4]);
                    this.Visit(joinVar);
                    RestoreState();
                    WriteWhitespace(" ");
                    WriteKeyword("in");
                    WriteWhitespace(" ");
                    this.VisitSubquery(m.Arguments[1]);
                    WriteWhitespace(" ");
                    WriteKeyword("on");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    this.Visit(m.Arguments[2]);
                    RestoreState();
                    WriteWhitespace(" ");
                    WriteKeyword("equals");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    this.Visit(m.Arguments[3]);
                    RestoreState();

                    if (isTopLevel && !tmp.wroteSelect)
                    {
                        WriteNewline();
                        WriteKeyword("select");
                        WriteWhitespace(" ");
                        // TODO: confirm that `joinVar` is correct here.
                        this.Visit(joinVar);
                        UpdateState(x => x.wroteSelect = true);
                    }
                    break;
                case "GroupJoin":
                    fromVar = DiscoverFromParameter(m.Arguments[2]);
                    isTopLevel = GetState().topLevel;
                    UpdateState(x => x.topLevel = false);

                    this.VisitSource(m.Arguments[0], fromVar);

                    WriteNewline();
                    WriteKeyword("join");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    this.Visit(DiscoverFromParameter(m.Arguments[3]));
                    RestoreState();
                    WriteWhitespace(" ");
                    WriteKeyword("in");
                    WriteWhitespace(" ");
                    this.VisitSubquery(m.Arguments[1]);
                    WriteWhitespace(" ");
                    WriteKeyword("on");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    this.Visit(m.Arguments[2]);
                    RestoreState();
                    WriteWhitespace(" ");
                    WriteKeyword("equals");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    this.Visit(m.Arguments[3]);
                    RestoreState();
                    WriteWhitespace(" ");
                    WriteKeyword("into");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    this.Visit(DiscoverJoinFromParameter(m.Arguments[4]));
                    RestoreState();

                    if (isTopLevel && !GetState().wroteSelect)
                    {
                        WriteNewline();
                        WriteKeyword("select");
                        WriteWhitespace(" ");
                        this.Visit(fromVar);
                        UpdateState(x => x.wroteSelect = true);
                    }
                    break;
                case "GroupBy":
                    this.Visit(m.Arguments[0]);
                    WriteNewline();
                    WriteKeyword("group");
                    WriteWhitespace(" ");
                    le = GetQuotedLambda(m.Arguments[2]);
                    if (le != null)
                    {
                        this.Visit(le.Body);
                    }
                    else
                    {
                        WriteComment("/* fail */");
                    }
                    WriteWhitespace(" ");
                    WriteKeyword("by");
                    WriteWhitespace(" ");
                    PushState(x => x.displayLambdaParameters = false);
                    this.Visit(m.Arguments[1]);
                    RestoreState();
                    // TODO: This has to be generated on the parent select clause...
                    //WriteWhitespace(" ");
                    //WriteKeyword("into");
                    //WriteWhitespace(" ");
                    //this.Visit(m.Arguments[1]);
                    break;
                case "Take":
                case "Skip":
                    this.Visit(m.Arguments[0]);
                    WriteNewline();
                    WriteOperator(".");
                    WriteIdentifier(m.Method.Name);
                    WriteOperator("(");
                    for (int i = 1; i < m.Arguments.Count; ++i)
                    {
                        this.Visit(m.Arguments[i]);
                        if (i < m.Arguments.Count - 1)
                        {
                            WriteOperator(",");
                            WriteWhitespace(" ");
                        }
                    }
                    WriteOperator(")");
                    break;
                case "OrderBy":
                case "OrderByDescending":
                    this.VisitSource(m.Arguments[0], DiscoverFromParameter(m.Arguments[1]));
                    if (GetState().wroteSelect)
                    {
                        // LINQ extension method syntax:
                        WriteNewline();
                        WriteOperator(".");
                        WriteIdentifier(m.Method.Name);
                        WriteOperator("(");
                        for (int i = 1; i < m.Arguments.Count; ++i)
                        {
                            this.Visit(m.Arguments[i]);
                            if (i < m.Arguments.Count - 1)
                            {
                                WriteOperator(",");
                                WriteWhitespace(" ");
                            }
                        }
                        WriteOperator(")");
                    }
                    else
                    {
                        // LINQ syntax inside a LINQ statement:
                        WriteNewline();
                        WriteKeyword("orderby");
                        WriteWhitespace(" ");
                        PushState(x => x.displayLambdaParameters = false);
                        this.Visit(m.Arguments[1]);
                        RestoreState();
                        WriteWhitespace(" ");
                        if (m.Method.Name.EndsWith("Descending"))
                            WriteKeyword("descending");
                        else
                            WriteKeyword("ascending");
                    }
                    break;
                case "ThenBy":
                case "ThenByDescending":
                    this.Visit(m.Arguments[0]);
                    if (GetState().wroteSelect)
                    {
                        // LINQ extension method syntax:
                        WriteNewline();
                        WriteOperator(".");
                        WriteIdentifier(m.Method.Name);
                        WriteOperator("(");
                        for (int i = 1; i < m.Arguments.Count; ++i)
                        {
                            this.Visit(m.Arguments[i]);
                            if (i < m.Arguments.Count - 1)
                            {
                                WriteOperator(",");
                                WriteWhitespace(" ");
                            }
                        }
                        WriteOperator(")");
                    }
                    else
                    {
                        WriteOperator(",");
                        WriteNewline();
                        WriteWhitespace("        ");
                        PushState(x => x.displayLambdaParameters = false);
                        this.Visit(m.Arguments[1]);
                        RestoreState();
                        WriteWhitespace(" ");
                        if (m.Method.Name.EndsWith("Descending"))
                            WriteKeyword("descending");
                        else
                            WriteKeyword("ascending");
                    }
                    break;
                case "Count":
                case "Sum":
                case "Contains":
                case "Distinct":
                case "DefaultIfEmpty":
                    bool nontrivial = (m.Arguments[0].NodeType != ExpressionType.MemberAccess) &&
                        (m.Arguments[0].NodeType != ExpressionType.Parameter);
                    if (nontrivial)
                    {
                        WriteOperator("(");
                        Indent();
                        WriteNewline();
                    }
                    this.Visit(m.Arguments[0]);
                    if (nontrivial)
                    {
                        Unindent();
                        WriteNewline();
                        WriteOperator(")");
                    }
                    WriteOperator(".");
                    WriteIdentifier(m.Method.Name);
                    WriteOperator("(");
                    for (int i = 1; i < m.Arguments.Count; ++i)
                    {
                        this.Visit(m.Arguments[i]);
                        if (i < m.Arguments.Count - 1)
                        {
                            WriteOperator(",");
                            WriteWhitespace(" ");
                        }
                    }
                    WriteOperator(")");
                    break;
                default:
                    WriteNewline();

                    // TODO: Support more Queryable methods.
                    WriteComment("/* " + m.Method.Name + " */");
                    break;
            }

            return m;
        }

        private LambdaExpression GetQuotedLambda(Expression e)
        {
            if (e.NodeType != ExpressionType.Quote) return null;
            Expression ueOp = ((UnaryExpression)e).Operand;
            if (ueOp.NodeType != ExpressionType.Lambda) return null;
            LambdaExpression le = (LambdaExpression)ueOp;
            return le;
        }

        private NewExpression GetQuotedLambdaNew(Expression e)
        {
            LambdaExpression le = GetQuotedLambda(e);
            if (le == null) return null;
            if (le.Body.NodeType != ExpressionType.New) return null;
            NewExpression ne = (NewExpression)le.Body;
            return ne;
        }

        private Expression DiscoverJoinFromParameter(Expression e)
        {
            LambdaExpression le = GetQuotedLambda(e);
            if (le == null) return null;
            if (le.Parameters.Count < 2) return e;
            return le.Parameters[1];
        }

        private Expression DiscoverFromParameter(Expression e)
        {
            LambdaExpression le = GetQuotedLambda(e);
            if (le == null) return null;
            if (le.Parameters.Count < 1) return e;
            return le.Parameters[0];
        }

        protected override Expression VisitConstant(ConstantExpression c)
        {
            if (c.Value == null)
            {
                WriteKeyword("null");
                return c;
            }

            Type vType = c.Type;
            Type cValueType = c.Value.GetType();
            if (vType.IsGenericType && (vType.GetGenericTypeDefinition() == typeof(System.Data.Linq.Table<>)))
            {
                // for a Table<T>, just display T:
                WriteType(vType.GetGenericArguments()[0]);
            }
#if false
            // TODO: how to discover this case...
            else if (cValueType.FullName == "System.Linq.Enumerable+<RangeIterator>d__b1")
            {
                WriteType(cValueType.DeclaringType);
                WriteOperator(".");
                WriteIdentifier("Range");
                WriteOperator("(");
                System.Reflection.FieldInfo fiStart = cValueType.GetField("start");
                System.Reflection.FieldInfo fiCount = cValueType.GetField("count");
                WriteValue(fiStart.FieldType, fiStart.GetValue(c.Value));
                WriteOperator(",");
                WriteWhitespace(" ");
                WriteValue(fiCount.FieldType, fiCount.GetValue(c.Value));
                WriteOperator(")");
            }
#endif
            else
            {
                WriteValue(vType, c.Value);
            }

            return c;
        }

        private Expression RemoveTransparentIdentifiers(MemberExpression m)
        {
            Expression newInner = m.Expression;

            ParameterExpression p;
            ConstantExpression c;
            MemberExpression me;

            if ((p = newInner as ParameterExpression) != null)
            {
                if (p.Name.StartsWith("<>h__TransparentIdentifier"))
                {
                    return Expression.Parameter(m.Type, m.Member.Name);
                }
            }
            else if ((c = newInner as ConstantExpression) != null)
            {
                if (c.Type.Name.StartsWith("<>h__TransparentIdentifier"))
                {
                    return Expression.Parameter(m.Type, m.Member.Name);
                }
                else if (c.Type.Name.StartsWith("<>c__DisplayClass"))
                {
                    return Expression.Parameter(m.Type, m.Member.Name);
                }
            }
            else if ((me = newInner as MemberExpression) != null)
            {
                if (me.Member.Name.StartsWith("<>h__TransparentIdentifier"))
                {
                    System.Reflection.PropertyInfo pInfo = (System.Reflection.PropertyInfo)m.Member;
                    return Expression.Parameter(pInfo.PropertyType, pInfo.Name);
                }
                else
                {
                    Expression inner = RemoveTransparentIdentifiers(me);
                    if (inner != me)
                    {
                        return Expression.MakeMemberAccess(inner, m.Member);
                    }
                    return m;
                }
            }

            return m;
        }

        protected override Expression VisitMemberAccess(MemberExpression m)
        {
            Expression e = RemoveTransparentIdentifiers(m);
            MemberExpression me = e as MemberExpression;
            if (me != null)
            {
                if (me.Expression == null)
                {
                    // Static property reference:
                    WriteType(me.Member.DeclaringType);
                }
                else
                {
                    this.Visit(me.Expression);
                }
                WriteOperator(".");
                WriteIdentifier(me.Member.Name);
            }
            else
            {
                this.Visit(e);
            }
            return e;
        }

        protected override NewExpression VisitNew(NewExpression nex)
        {
            WriteKeyword("new");
            WriteWhitespace(" ");
            if (nex.Type.Name.StartsWith("<>f__AnonymousType"))
            {
                WriteOperator("{");
                WriteWhitespace(" ");
                if ((nex.Members != null) && (nex.Members.Count == nex.Arguments.Count))
                {
                    for (int i = 0; i < nex.Arguments.Count; ++i)
                    {
                        WriteIdentifier(nex.Members[i].Name.RemoveIfStartsWith("get_"));
                        WriteWhitespace(" ");
                        WriteOperator("=");
                        WriteWhitespace(" ");
                        this.Visit(nex.Arguments[i]);
                        if (i < nex.Arguments.Count - 1)
                        {
                            WriteOperator(",");
                            WriteWhitespace(" ");
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < nex.Arguments.Count; ++i)
                    {
                        this.Visit(nex.Arguments[i]);
                        if (i < nex.Arguments.Count - 1)
                        {
                            WriteOperator(",");
                            WriteWhitespace(" ");
                        }
                    }
                }
                WriteWhitespace(" ");
                WriteOperator("}");
            }
            else
            {
                WriteType(nex.Type);
                WriteOperator("(");
                for (int i = 0; i < nex.Arguments.Count; ++i)
                {
                    this.Visit(nex.Arguments[i]);
                    if (i < nex.Arguments.Count - 1)
                    {
                        WriteOperator(",");
                        WriteWhitespace(" ");
                    }
                }
                WriteOperator(")");
            }
            return nex;
        }

        protected override Expression VisitLambda(LambdaExpression lambda)
        {
            if (GetState().displayLambdaParameters)
            {
                if (lambda.Parameters.Count > 1)
                {
                    WriteOperator("(");
                    for (int i = 0; i < lambda.Parameters.Count; ++i)
                    {
                        this.Visit(lambda.Parameters[i]);
                        if (i < lambda.Parameters.Count - 1)
                        {
                            WriteOperator(",");
                            WriteWhitespace(" ");
                        }
                    }
                    WriteOperator(")");
                }
                else if (lambda.Parameters.Count == 1)
                {
                    this.Visit(lambda.Parameters[0]);
                }
                else
                {
                    WriteOperator("(");
                    WriteOperator(")");
                }
                WriteWhitespace(" ");
                WriteOperator("=>");
                WriteWhitespace(" ");
            }
            this.Visit(lambda.Body);
            return lambda;
        }

        protected override Expression VisitParameter(ParameterExpression p)
        {
            WriteIdentifier(p.Name);
            return p;
        }

        protected override Expression VisitInvocation(InvocationExpression iv)
        {
            this.Visit(iv.Expression);
            WriteOperator("(");
            WriteExpressionListCommaDelimited(iv.Arguments);
            WriteOperator(")");
            return iv;
        }

        protected override Expression VisitConditional(ConditionalExpression c)
        {
            this.Visit(c.Test);
            WriteWhitespace(" ");
            WriteOperator("?");
            WriteWhitespace(" ");
            this.Visit(c.IfTrue);
            WriteWhitespace(" ");
            WriteOperator(":");
            WriteWhitespace(" ");
            this.Visit(c.IfFalse);
            return c;
        }

        protected override Expression VisitBinary(BinaryExpression b)
        {
            if (b.NodeType == ExpressionType.ArrayIndex)
            {
                this.Visit(b.Left);
                WriteOperator("[");
                this.Visit(b.Right);
                WriteOperator("]");
                return b;
            }

            WriteOperator("(");
            this.Visit(b.Left);
            WriteWhitespace(" ");
            switch (b.NodeType)
            {
                case ExpressionType.Add:
                    WriteWhitespace("+"); break;
                case ExpressionType.AddChecked:
                    WriteWhitespace("+"); break;
                case ExpressionType.Subtract:
                    WriteWhitespace("-"); break;
                case ExpressionType.SubtractChecked:
                    WriteWhitespace("-"); break;
                case ExpressionType.Multiply:
                    WriteWhitespace("*"); break;
                case ExpressionType.MultiplyChecked:
                    WriteWhitespace("*"); break;
                case ExpressionType.Divide:
                    WriteWhitespace("/"); break;
                case ExpressionType.Modulo:
                    WriteWhitespace("%"); break;
                case ExpressionType.And:
                    WriteWhitespace("&"); break;
                case ExpressionType.AndAlso:
                    WriteWhitespace("&&"); break;
                case ExpressionType.Or:
                    WriteWhitespace("|"); break;
                case ExpressionType.OrElse:
                    WriteWhitespace("||"); break;
                case ExpressionType.LessThan:
                    WriteWhitespace("<"); break;
                case ExpressionType.LessThanOrEqual:
                    WriteWhitespace("<="); break;
                case ExpressionType.GreaterThan:
                    WriteWhitespace(">"); break;
                case ExpressionType.GreaterThanOrEqual:
                    WriteWhitespace(">="); break;
                case ExpressionType.Equal:
                    WriteWhitespace("=="); break;
                case ExpressionType.NotEqual:
                    WriteWhitespace("!="); break;
                case ExpressionType.Coalesce:
                    WriteWhitespace("??"); break;
                case ExpressionType.ArrayIndex:
                    WriteWhitespace("[]"); break;
                case ExpressionType.RightShift:
                    WriteWhitespace(">>"); break;
                case ExpressionType.LeftShift:
                    WriteWhitespace("<<"); break;
                case ExpressionType.ExclusiveOr:
                    WriteWhitespace("^"); break;

                default:
                    throw new NotSupportedException(string.Format("The binary operator '{0}' is not supported", b.NodeType));
            }
            WriteWhitespace(" ");
            this.Visit(b.Right);
            WriteOperator(")");
            return b;
        }

        protected override Expression VisitUnary(UnaryExpression u)
        {
            switch (u.NodeType)
            {
                case ExpressionType.Negate:
                    WriteOperator("-");
                    this.Visit(u.Operand);
                    break;
                case ExpressionType.NegateChecked:
                    WriteOperator("-");
                    this.Visit(u.Operand);
                    break;
                case ExpressionType.Not:
                    WriteOperator("!");
                    this.Visit(u.Operand);
                    break;
                case ExpressionType.Convert:
                    WriteOperator("(");
                    WriteType(u.Type);
                    WriteOperator(")");
                    this.Visit(u.Operand);
                    break;
                case ExpressionType.ConvertChecked:
                    WriteKeyword("checked");
                    WriteOperator("(");
                    WriteOperator("(");
                    WriteType(u.Type);
                    WriteOperator(")");
                    this.Visit(u.Operand);
                    WriteOperator(")");
                    break;
                case ExpressionType.ArrayLength:
                    this.Visit(u.Operand);
                    // TODO: confirm!
                    WriteOperator(".");
                    WriteIdentifier("Length");
                    break;
                case ExpressionType.Quote:
                    this.Visit(u.Operand);
                    break;
                case ExpressionType.TypeAs:
                    WriteOperator("(");
                    this.Visit(u.Operand);
                    // TODO: confirm!
                    WriteWhitespace(" ");
                    WriteKeyword("as");
                    WriteWhitespace(" ");
                    WriteType(u.Type);
                    WriteOperator(")");
                    break;
                default:
                    throw new NotSupportedException(string.Format("The unary operator '{0}' is not supported", u.NodeType));
            }
            return u;
        }

        protected override Expression VisitNewArray(NewArrayExpression na)
        {
            WriteKeyword("new");
            WriteWhitespace(" ");
            Debug.Assert(na.Type.IsArray);
            WriteType(na.Type.GetElementType());
            WriteOperator("[");
            if (na.NodeType == ExpressionType.NewArrayBounds)
            {
                WriteExpressionListCommaDelimited(na.Expressions);
            }
            WriteOperator("]");
            if (na.NodeType == ExpressionType.NewArrayInit)
            {
                WriteWhitespace(" ");
                WriteOperator("{");
                WriteWhitespace(" ");
                WriteExpressionListCommaDelimited(na.Expressions);
                WriteWhitespace(" ");
                WriteOperator("}");
            }
            return na;
        }

        protected override Expression VisitTypeIs(TypeBinaryExpression b)
        {
            this.Visit(b.Expression);
            WriteWhitespace(" ");
            WriteKeyword("is");
            WriteWhitespace(" ");
            WriteType(b.TypeOperand);
            return b;
        }

        protected override Expression VisitListInit(ListInitExpression init)
        {
            this.VisitNew(init.NewExpression);
            WriteWhitespace(" ");
            WriteOperator("{");
            WriteWhitespace(" ");
            WriteExpressionListCommaDelimited(new ReadOnlyCollection<Expression>((
                from ine in init.Initializers
                select ine.Arguments[0]
            ).ToList()));
            WriteWhitespace(" ");
            WriteOperator("}");
            return init;
        }

        protected override MemberAssignment VisitMemberAssignment(MemberAssignment assignment)
        {
            return base.VisitMemberAssignment(assignment);
        }

        protected override Expression VisitMemberInit(MemberInitExpression init)
        {
            return base.VisitMemberInit(init);
        }

        protected override MemberListBinding VisitMemberListBinding(MemberListBinding binding)
        {
            return base.VisitMemberListBinding(binding);
        }

        protected override MemberMemberBinding VisitMemberMemberBinding(MemberMemberBinding binding)
        {
            return base.VisitMemberMemberBinding(binding);
        }

        #endregion
    }
}
