﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.IO;
using System.Text;
using Kaplan.Framework.Web.MarkDown;
using Kaplan.Framework.Data.Caching;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using Kaplan.Framework.Data.Linq;
using System.Linq.Expressions;

namespace Linq
{
    public class LinqConsoleColorWriter : LinqSyntaxExpressionFormatter
    {
        protected override Expression VisitQuery(Expression query)
        {
            WriteComment("// C# LINQ query:");
            WriteKeyword("var");
            WriteWhitespace(" ");
            WriteIdentifier("query");
            WriteWhitespace(" ");
            WriteOperator("=");
            Indent();
            WriteNewline();
            Expression ret = this.Visit(query);
            Unindent();
            WriteOperator(";");
            return ret;
        }

        public override void WriteFormat(Expression query, TextWriter tw)
        {
            bool writingToConsole = (tw == Console.Out);
            Reset();

            VisitQuery(query);

            foreach (var tok in output)
            {
                switch (tok.TokenType)
                {
                    case TokenType.Newline:
                        tw.WriteLine();
                        tw.Write(String.Concat(Enumerable.Repeat<string>(indentString, tok.IndentationDepth.Value).ToArray()));
                        break;
                    case TokenType.Comment:
                        if (writingToConsole) Console.ForegroundColor = ConsoleColor.Green;
                        tw.Write(tok.Text);
                        break;
                    case TokenType.Keyword:
                        if (writingToConsole) Console.ForegroundColor = ConsoleColor.DarkCyan;
                        tw.Write(tok.Text);
                        break;
                    case TokenType.ValueType:
                        if (writingToConsole) Console.ForegroundColor = ConsoleColor.Yellow;
                        tw.Write(tok.Text);
                        break;
                    case TokenType.ClassType:
                        if (writingToConsole) Console.ForegroundColor = ConsoleColor.Magenta;
                        tw.Write(tok.Text);
                        break;
                    case TokenType.InterfaceType:
                        if (writingToConsole) Console.ForegroundColor = ConsoleColor.DarkYellow;
                        tw.Write(tok.Text);
                        break;
                    case TokenType.Identifier:
                        if (writingToConsole) Console.ForegroundColor = ConsoleColor.Gray;
                        tw.Write(tok.Text);
                        break;
                    case TokenType.ConstantString:
                        if (writingToConsole) Console.ForegroundColor = ConsoleColor.Red;
                        tw.Write(tok.Text);
                        break;
                    case TokenType.ConstantIntegral:
                    case TokenType.Unformatted:
                    default:
                        if (writingToConsole) Console.ForegroundColor = ConsoleColor.Gray;
                        tw.Write(tok.Text);
                        break;
                }
            }
        }
    }
}
