﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class DeveloperTransformAlgorithm : ITransformAlgorithm
    {
        public string AlgorithmName { get { return "Interviewee's Implementation"; } }

        /// <summary>
        /// Transforms a 2D rectangular grid of solid/empty cells into a set of 2D line segments for display.
        /// </summary>
        /// <param name="map"></param>
        /// <param name="startingPosition"></param>
        /// <returns></returns>
        public IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition)
        {
            // PROBLEM:
            // You are given a 2-dimensional map of square cells. Each cell may be occupied with solid impassable material
            // or may be empty and passable. This map is represented in code as a rectangular array of booleans where a
            // `true` value represents a solid block and a `false` value represents an empty/open block.

            // The map data represents a series of "rooms" which are defined by the outline of connected strips of solid cells
            // going either horizontally or vertically. There are no diagonally slanted walls. If a solid block is surrounded
            // on all 4 sides by empty space then it should be represented by 4 line segments; one on each edge.

            // Assume `startingPosition` represents a Point location inside of the map best suited to traversing the inner
            // space of rooms represented within the map. The Point's X and Y locations are in array-index coordinates, i.e.
            // X  E  [0 .. n),  Y  E  [0 .. m)  where  n X m  is the size of the map.

            // YOUR TASK:
            // Implement an algorithm to produce a set of `LineSegment` structures which represent the "inner outline"
            // of this 2-dimensional map, reachable from the `startingPosition`.
            
            // BONUS:
            // Be careful about the line segments' orientations; i.e. the line segments should be constructed in
            // clockwise order of Begin to End to form an enclosed empty space, and in counter-clockwise order for an outward-
            // facing solid-filled space.

            // EXTRA BONUS:
            // Reduce the set of line segments to the shortest set of longest line segments; i.e. walls that continue for
            // a length of more than one cell in a direction should be made into one single line segment instance. Having
            // no unnecessary line segment breaks in a contiguous wall section would be a true ideal here.

            // Basic range checks:
            if (!IsPointInRange(startingPosition.X, 0, map.Width - 1)) throw new ArgumentOutOfRangeException("startingPosition.X");
            if (!IsPointInRange(startingPosition.Y, 0, map.Height - 1)) throw new ArgumentOutOfRangeException("startingPosition.Y");

            if (map.IsSolid(startingPosition)) yield break;

            // --------- YOUR ALGORITHM GOES HERE --------

            // Example output:
            yield return new LineSegment(new Point(1, 1), new Point(8, 1));
            yield return new LineSegment(new Point(8, 1), new Point(8, 8));
            yield return new LineSegment(new Point(8, 8), new Point(1, 8));
            yield return new LineSegment(new Point(1, 8), new Point(1, 1));
        }

        private bool IsPointInRange(int p, int lower, int upper)
        {
            if (p < lower) return false;
            if (p > upper) return false;
            return true;
        }
    }
}
