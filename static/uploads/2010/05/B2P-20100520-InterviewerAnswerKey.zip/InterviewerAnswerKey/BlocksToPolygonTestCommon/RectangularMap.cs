﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class RectangularMap
    {
        public RectangularMap(int width, int height)
        {
            this.grid = new bool[height, width];
            this._height = height;
            this._width = width;
        }

        public RectangularMap(RectangularMap map)
        {
            this.grid = new bool[map.Height, map.Width];
            this._height = map.Height;
            this._width = map.Width;

            // Simplest way to copy data:
            for (int y = 0; y < _height; ++y)
                for (int x = 0; x < _width; ++x)
                    this.grid[y, x] = map.grid[y, x];
        }

        public RectangularMap(byte[] inputData)
        {
            this._width = BitConverter.ToInt32(inputData, 0);
            this._height = BitConverter.ToInt32(inputData, 4);
            this.grid = new bool[_height, _width];
            using (var ms = new System.IO.MemoryStream(inputData, 8, inputData.Length - 8, false))
            {
                // Read in the bit-packed boolean values:
                for (int y = 0; y < _height; ++y)
                    for (int x = 0; x < _width; x += 8)
                    {
                        int n = ms.ReadByte();
                        if ((x + 0) < _width) this.grid[y, x + 0] = ((n & (1 << 0)) == (1 << 0));
                        if ((x + 1) < _width) this.grid[y, x + 1] = ((n & (1 << 1)) == (1 << 1));
                        if ((x + 2) < _width) this.grid[y, x + 2] = ((n & (1 << 2)) == (1 << 2));
                        if ((x + 3) < _width) this.grid[y, x + 3] = ((n & (1 << 3)) == (1 << 3));
                        if ((x + 4) < _width) this.grid[y, x + 4] = ((n & (1 << 4)) == (1 << 4));
                        if ((x + 5) < _width) this.grid[y, x + 5] = ((n & (1 << 5)) == (1 << 5));
                        if ((x + 6) < _width) this.grid[y, x + 6] = ((n & (1 << 6)) == (1 << 6));
                        if ((x + 7) < _width) this.grid[y, x + 7] = ((n & (1 << 7)) == (1 << 7));
                    }
            }
        }

        public RectangularMap(int width, int height, RectangularMap map)
        {
            this.grid = new bool[height, width];
            this._height = height;
            this._width = width;

            // Simplest way to copy data:
            for (int y = 0; y < Math.Min(_height, map.Height); ++y)
                for (int x = 0; x < Math.Min(_width, map.Width); ++x)
                    this.grid[y, x] = map.grid[y, x];
        }

        public byte[] Serialize()
        {
            using (var ms = new System.IO.MemoryStream(8 + (_width * _height) / 8))
            {
                using (var bw = new System.IO.BinaryWriter(ms))
                {
                    bw.Write(_width);
                    bw.Write(_height);
                    bw.Flush();
                    // Write out the bit-packed boolean values:
                    for (int y = 0; y < _height; ++y)
                        for (int x = 0; x < _width; x += 8)
                        {
                            int n0 = (x + 0) < _width ? (this.grid[y, x + 0] ? 1 : 0) : 0;
                            int n1 = (x + 1) < _width ? (this.grid[y, x + 1] ? 1 : 0) : 0;
                            int n2 = (x + 2) < _width ? (this.grid[y, x + 2] ? 1 : 0) : 0;
                            int n3 = (x + 3) < _width ? (this.grid[y, x + 3] ? 1 : 0) : 0;
                            int n4 = (x + 4) < _width ? (this.grid[y, x + 4] ? 1 : 0) : 0;
                            int n5 = (x + 5) < _width ? (this.grid[y, x + 5] ? 1 : 0) : 0;
                            int n6 = (x + 6) < _width ? (this.grid[y, x + 6] ? 1 : 0) : 0;
                            int n7 = (x + 7) < _width ? (this.grid[y, x + 7] ? 1 : 0) : 0;
                            ms.WriteByte((byte)(
                                (n0 << 0) | (n1 << 1) | (n2 << 2) | (n3 << 3) |
                                (n4 << 4) | (n5 << 5) | (n6 << 6) | (n7 << 7)
                            ));
                        }
                    return ms.ToArray();
                }
            }
        }

        private bool[,] grid;
        private int _width, _height;

        public int Width { get { return _width; } }
        public int Height { get { return _height; } }

        public bool IsSolid(System.Drawing.Point pnt)
        {
            if (pnt.X >= _width) return false;
            if (pnt.Y >= _height) return false;
            if (pnt.X < 0) return false;
            if (pnt.Y < 0) return false;

            return grid[pnt.Y, pnt.X];
        }

        public void Set(int x, int y, bool value)
        {
            if (x >= _width) return;
            if (y >= _height) return;
            if (x < 0) return;
            if (y < 0) return;

            grid[y, x] = value;
        }

        public void DrawHLine(int x, int y, int w, bool value)
        {
            if (y < 0) return;
            if (y >= _height) return;
            if (x < 0) x = 0;
            if (x + w >= _width) w = _width - x;

            for (int n = x; n < x + w; ++n)
                grid[y, n] = value;
        }

        public void DrawVLine(int x, int y, int h, bool value)
        {
            if (x < 0) return;
            if (x >= _width) return;
            if (y < 0) y = 0;
            if (y + h >= _height) h = _height - y;

            for (int n = y; n < y + h; ++n)
                grid[n, x] = value;
        }

        public void DrawRectangle(int x, int y, int w, int h, bool value)
        {
            DrawHLine(x, y, w, value);
            DrawHLine(x, y + h - 1, w, value);
            DrawVLine(x, y, h, value);
            DrawVLine(x + w - 1, y, h, value);
        }

        public void FillRectangle(int x, int y, int w, int h, bool value)
        {
            for (int i = y; i < y + h; ++i)
                DrawHLine(x, i, w, value);
        }
    }
}
