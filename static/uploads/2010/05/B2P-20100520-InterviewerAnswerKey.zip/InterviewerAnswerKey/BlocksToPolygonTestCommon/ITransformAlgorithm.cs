﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public interface ITransformAlgorithm
    {
        /// <summary>
        /// Gets the algorithm implementation's name/description to be displayed on the UI.
        /// </summary>
        string AlgorithmName { get; }

        /// <summary>
        /// Transforms the rectangular <paramref name="map"/> of solid/empty cells into a set of line segments
        /// which represent the inner outline of the walls reachable from <paramref name="startingPosition"/>.
        /// </summary>
        /// <param name="map"></param>
        /// <param name="startingPosition"></param>
        /// <returns></returns>
        IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition);
    }
}
