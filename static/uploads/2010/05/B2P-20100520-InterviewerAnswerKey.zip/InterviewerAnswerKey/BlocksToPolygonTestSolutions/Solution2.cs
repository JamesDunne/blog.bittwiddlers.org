﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class Solution2TransformAlgorithm : ITransformAlgorithm
    {
        public string AlgorithmName { get { return "Recursion Stack<T>, shortest lines, orphaned areas"; } }

        public IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition)
        {
            // Create a structure to mark which cells have been visited:
            bool[,] visited = new bool[map.Height, map.Width];

            // Create a stack to hold the locations to visit for the flood-fill algorithm:
            Stack<Point> locsToVisit = new Stack<Point>(map.Height * map.Width);
            // Start with the starting position given:
            locsToVisit.Push(startingPosition);

            // Recurse until we run out of points to visit:
            while (locsToVisit.Count > 0)
            {
                // Get the point to visit:
                Point cur = locsToVisit.Pop();

                // If this position is already visited then continue to the next point:
                if (visited[cur.Y, cur.X]) continue;

                // Mark this point as having been visited:
                visited[cur.Y, cur.X] = true;

                // Check each of four cardinal directions for solid blocks:

                // North:
                if (IsPointInRange(cur.Y - 1, 0, map.Height - 1))
                {
                    var tmp = new Point(cur.X, cur.Y - 1);
                    if (map.IsSolid(tmp))
                    {
                        yield return new LineSegment(
                            new Point(tmp.X, cur.Y),
                            new Point(tmp.X + 1, cur.Y)
                        );
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }

                // East:
                if (IsPointInRange(cur.X + 1, 0, map.Width - 1))
                {
                    var tmp = new Point(cur.X + 1, cur.Y);
                    if (map.IsSolid(tmp))
                    {
                        yield return new LineSegment(
                            new Point(tmp.X, tmp.Y),
                            new Point(tmp.X, tmp.Y + 1)
                        );
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }

                // South:
                if (IsPointInRange(cur.Y + 1, 0, map.Height - 1))
                {
                    var tmp = new Point(cur.X, cur.Y + 1);
                    if (map.IsSolid(tmp))
                    {
                        yield return new LineSegment(
                            new Point(tmp.X + 1, tmp.Y),
                            new Point(tmp.X, tmp.Y)
                        );
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }

                // West:
                if (IsPointInRange(cur.X - 1, 0, map.Width - 1))
                {
                    var tmp = new Point(cur.X - 1, cur.Y);
                    if (map.IsSolid(tmp))
                    {
                        yield return new LineSegment(
                            new Point(tmp.X + 1, tmp.Y + 1),
                            new Point(tmp.X + 1, tmp.Y)
                        );
                    }
                    else
                    {
                        locsToVisit.Push(tmp);
                    }
                }
            }

            locsToVisit = null;
        }

        private static bool IsPointInRange(int p, int lower, int upper)
        {
            if (p < lower) return false;
            if (p > upper) return false;
            return true;
        }
    }
}
