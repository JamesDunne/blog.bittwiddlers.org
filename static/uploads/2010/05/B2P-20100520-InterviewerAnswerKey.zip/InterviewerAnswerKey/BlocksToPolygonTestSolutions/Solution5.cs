﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class Solution5TransformAlgorithm : ITransformAlgorithm
    {
        public string AlgorithmName { get { return "Nested for-loops, shortest lines, no orphaned areas"; } }

        public IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition)
        {
            for (int y = 0; y < map.Height; ++y)
            {
                for (int x = 0; x < map.Width; ++x)
                {
                    // Check each of four cardinal directions for solid blocks:
                    var cur = new Point(x, y);
                    if (map.IsSolid(cur)) continue;

                    // North:
                    if (IsPointInRange(cur.Y - 1, 0, map.Height - 1))
                    {
                        var tmp = new Point(cur.X, cur.Y - 1);
                        if (map.IsSolid(tmp))
                        {
                            // No linesegments to the left or right, create a new one:
                            yield return new LineSegment(
                                new Point(tmp.X, cur.Y),
                                new Point(tmp.X + 1, cur.Y)
                            );
                        }
                    }

                    // East:
                    if (IsPointInRange(cur.X + 1, 0, map.Width - 1))
                    {
                        var tmp = new Point(cur.X + 1, cur.Y);
                        if (map.IsSolid(tmp))
                        {
                            yield return new LineSegment(
                                new Point(tmp.X, tmp.Y),
                                new Point(tmp.X, tmp.Y + 1)
                            );
                        }
                    }

                    // South:
                    if (IsPointInRange(cur.Y + 1, 0, map.Height - 1))
                    {
                        var tmp = new Point(cur.X, cur.Y + 1);
                        if (map.IsSolid(tmp))
                        {
                            yield return new LineSegment(
                                new Point(tmp.X + 1, tmp.Y),
                                new Point(tmp.X, tmp.Y)
                            );
                        }
                    }

                    // West:
                    if (IsPointInRange(cur.X - 1, 0, map.Width - 1))
                    {
                        var tmp = new Point(cur.X - 1, cur.Y);
                        if (map.IsSolid(tmp))
                        {
                            yield return new LineSegment(
                                new Point(tmp.X + 1, tmp.Y + 1),
                                new Point(tmp.X + 1, tmp.Y)
                            );
                        }
                    }
                }
            }
        }

        private static bool IsPointInRange(int p, int lower, int upper)
        {
            if (p < lower) return false;
            if (p > upper) return false;
            return true;
        }

        public struct CellState
        {
            public bool Visited;
            public LineSegmentRef lsiN;
            public LineSegmentRef lsiS;
            public LineSegmentRef lsiE;
            public LineSegmentRef lsiW;
        }

        public class LineSegmentRef
        {
            public LineSegment Segment;
        }
    }
}
