﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class Solution7TransformAlgorithm : ITransformAlgorithm
    {
        public string AlgorithmName { get { return "LINQ, shortest lines, no orphaned areas"; } }

        public IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition)
        {
            return
                from y in Enumerable.Range(0, map.Height)
                from x in Enumerable.Range(0, map.Width)
                let cur = new Point(x, y)
                // Early out if we're not on an empty cell:
                where !map.IsSolid(cur)
                // Progress in 4 cardinal directions in a clockwise order, where 0 is north, 1 is east, 2 is south, 3 is west:
                from dir in Enumerable.Range(0, 4)
                let ty =
                    dir == 0 ? cur.Y - 1 :
                    dir == 1 ? cur.Y :
                    dir == 2 ? cur.Y + 1 :
                    cur.Y
                let tx =
                    dir == 0 ? cur.X :
                    dir == 1 ? cur.X + 1 :
                    dir == 2 ? cur.X :
                    cur.X - 1
                let updown = dir == 0 || dir == 2
                // Make sure our prospective temporary point is in the map boundaries:
                where ((updown && IsPointInRange(ty, 0, map.Height - 1)) || !updown) &&
                      ((!updown && IsPointInRange(tx, 0, map.Width - 1)) || updown)
                // Mark the point:
                let tmp = new Point(tx, ty)
                where map.IsSolid(tmp)
                // Select the line segment that best represents this edge:
                select
                    dir == 0 ?
                        new LineSegment(
                            new Point(tmp.X, cur.Y),
                            new Point(tmp.X + 1, cur.Y)
                        ) :
                    dir == 1 ?
                        new LineSegment(
                            new Point(tmp.X, tmp.Y),
                            new Point(tmp.X, tmp.Y + 1)
                        ) :
                    dir == 2 ?
                        new LineSegment(
                            new Point(tmp.X + 1, tmp.Y),
                            new Point(tmp.X, tmp.Y)
                        ) :
                    new LineSegment(
                        new Point(tmp.X + 1, tmp.Y + 1),
                        new Point(tmp.X + 1, tmp.Y)
                    );
        }

        private static bool IsPointInRange(int p, int lower, int upper)
        {
            if (p < lower) return false;
            if (p > upper) return false;
            return true;
        }
    }
}
