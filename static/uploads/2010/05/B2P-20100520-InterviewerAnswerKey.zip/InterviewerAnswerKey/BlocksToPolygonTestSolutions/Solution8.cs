﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class Solution8TransformAlgorithm : ITransformAlgorithm
    {
        public string AlgorithmName { get { return "4 LINQ concats, shortest lines, no orphaned areas"; } }

        public IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition)
        {
            var emptyCells = (
                from y in Enumerable.Range(0, map.Height)
                from x in Enumerable.Range(0, map.Width)
                let cur = new Point(x, y)
                // Early out if we're not on an empty cell:
                where !map.IsSolid(cur)
                select cur
            ).ToArray();

            return (
                from cur in emptyCells
                let ty = cur.Y - 1
                let tx = cur.X
                // Make sure our prospective temporary point is in the map boundaries:
                where IsPointInRange(ty, 0, map.Height - 1)
                // Mark the point:
                let tmp = new Point(tx, ty)
                where map.IsSolid(tmp)
                // Select the line segment that best represents this edge:
                select new LineSegment(
                    new Point(tmp.X, cur.Y),
                    new Point(tmp.X + 1, cur.Y)
                )
            ).Concat(
                from cur in emptyCells
                let ty = cur.Y
                let tx = cur.X + 1
                // Make sure our prospective temporary point is in the map boundaries:
                where IsPointInRange(tx, 0, map.Width - 1)
                // Mark the point:
                let tmp = new Point(tx, ty)
                where map.IsSolid(tmp)
                // Select the line segment that best represents this edge:
                select new LineSegment(
                    new Point(tmp.X, tmp.Y),
                    new Point(tmp.X, tmp.Y + 1)
                )
            ).Concat(
                from cur in emptyCells
                let ty = cur.Y + 1
                let tx = cur.X
                // Make sure our prospective temporary point is in the map boundaries:
                where IsPointInRange(ty, 0, map.Height - 1)
                // Mark the point:
                let tmp = new Point(tx, ty)
                where map.IsSolid(tmp)
                // Select the line segment that best represents this edge:
                select new LineSegment(
                    new Point(tmp.X + 1, tmp.Y),
                    new Point(tmp.X, tmp.Y)
                )
            ).Concat(
                from cur in emptyCells
                let ty = cur.Y
                let tx = cur.X - 1
                // Make sure our prospective temporary point is in the map boundaries:
                where IsPointInRange(tx, 0, map.Width - 1)
                // Mark the point:
                let tmp = new Point(tx, ty)
                where map.IsSolid(tmp)
                // Select the line segment that best represents this edge:
                select new LineSegment(
                    new Point(tmp.X + 1, tmp.Y + 1),
                    new Point(tmp.X + 1, tmp.Y)
                )
            );
        }

        private static bool IsPointInRange(int p, int lower, int upper)
        {
            if (p < lower) return false;
            if (p > upper) return false;
            return true;
        }
    }
}
