﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace BlocksToPolygonTest
{
    public class Solution1TransformAlgorithm : ITransformAlgorithm
    {
        public string AlgorithmName { get { return "Recursion Function, shortest lines, orphaned areas"; } }

        /// <summary>
        /// We need a separate Solver class since you cannot call IEnumerable-returning methods recursively.
        /// </summary>
        private class Solver
        {
            private RectangularMap map;
            private bool[,] visited;
            private List<LineSegment> segs;

            public List<LineSegment> Segments
            {
                get { return this.segs; }
            }

            public Solver(RectangularMap map)
            {
                this.map = map;
                this.segs = new List<LineSegment>();

                // Create a structure to mark which cells have been visited:
                this.visited = new bool[map.Height, map.Width];
            }

            public void RecursiveImpl(Point cur)
            {
                // If this position is already visited then continue to the next point:
                if (visited[cur.Y, cur.X]) return;

                // Mark this point as having been visited:
                visited[cur.Y, cur.X] = true;

                // Check each of four cardinal directions for solid blocks:

                // North:
                if (IsPointInRange(cur.Y - 1, 0, map.Height - 1))
                {
                    var tmp = new Point(cur.X, cur.Y - 1);
                    if (map.IsSolid(tmp))
                    {
                        segs.Add(new LineSegment(
                            new Point(tmp.X, cur.Y),
                            new Point(tmp.X + 1, cur.Y)
                        ));
                    }
                    else
                    {
                        RecursiveImpl(tmp);
                    }
                }

                // East:
                if (IsPointInRange(cur.X + 1, 0, map.Width - 1))
                {
                    var tmp = new Point(cur.X + 1, cur.Y);
                    if (map.IsSolid(tmp))
                    {
                        segs.Add(new LineSegment(
                            new Point(tmp.X, tmp.Y),
                            new Point(tmp.X, tmp.Y + 1)
                        ));
                    }
                    else
                    {
                        RecursiveImpl(tmp);
                    }
                }

                // South:
                if (IsPointInRange(cur.Y + 1, 0, map.Height - 1))
                {
                    var tmp = new Point(cur.X, cur.Y + 1);
                    if (map.IsSolid(tmp))
                    {
                        segs.Add(new LineSegment(
                            new Point(tmp.X + 1, tmp.Y),
                            new Point(tmp.X, tmp.Y)
                        ));
                    }
                    else
                    {
                        RecursiveImpl(tmp);
                    }
                }

                // West:
                if (IsPointInRange(cur.X - 1, 0, map.Width - 1))
                {
                    var tmp = new Point(cur.X - 1, cur.Y);
                    if (map.IsSolid(tmp))
                    {
                        segs.Add(new LineSegment(
                            new Point(tmp.X + 1, tmp.Y + 1),
                            new Point(tmp.X + 1, tmp.Y)
                        ));
                    }
                    else
                    {
                        RecursiveImpl(tmp);
                    }
                }
            }

            private static bool IsPointInRange(int p, int lower, int upper)
            {
                if (p < lower) return false;
                if (p > upper) return false;
                return true;
            }
        }

        public IEnumerable<LineSegment> TransformBlocksToLineSegments(RectangularMap map, Point startingPosition)
        {
            Solver sv = new Solver(map);
            sv.RecursiveImpl(startingPosition);
            return sv.Segments;
        }
    }
}
